/*

Filename: /client/routes.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Contains all FlowRouter routes

*/

import { Meteor } from 'meteor/meteor';
import { FlowRouter } from 'meteor/kadira:flow-router';
import { BlazeLayout } from 'meteor/kadira:blaze-layout';

// Import layout
import '../imports/ui/layouts/body/body.js';


// Define URLS (Routes) and import all Pages
import '../imports/ui/pages/home/home.js';
FlowRouter.route('/', {
  name: 'home',
  action() {
    BlazeLayout.render('App_body', { page: 'home' });
  },
});

import '../imports/ui/pages/projects/projects.js';
FlowRouter.route('/projects', {
  name: 'projects',
  action() {
    BlazeLayout.render('App_body', { page: 'projects' });
  },
});

import '../imports/ui/pages/projects/editProject.js';
FlowRouter.route('/projects/:projectId', {
  name: 'editProduct',
  action() {
    BlazeLayout.render('App_body', { page: 'editProject' });
  },
});

import '../imports/ui/pages/searches/searches.js';
FlowRouter.route('/searches', {
  name: 'searches',
  action() {
    BlazeLayout.render('App_body', { page: 'searches' });
  },
});

import '../imports/ui/pages/searches/editSearch.js';
FlowRouter.route('/searches/:searchId', {
  name: 'editSearch',
  action() {
    BlazeLayout.render('App_body', { page: 'editSearch' });
  },
});

import '../imports/ui/pages/searches/compareSearch.js';
FlowRouter.route('/searches/compare/:searchId', {
  name: 'compareSearch',
  action() {
    BlazeLayout.render('App_body', { page: 'compareSearch' });
  },
});

import '../imports/ui/pages/products/products.js';
FlowRouter.route('/products', {
  name: 'products',
  action() {
    BlazeLayout.render('App_body', { page: 'products' });
  },
});

import '../imports/ui/pages/products/editProduct.js';
FlowRouter.route('/products/:productId', {
  name: 'editProduct',
  action() {
    BlazeLayout.render('App_body', { page: 'editProduct' });
  },
});

import '../imports/ui/pages/components/components.js';
FlowRouter.route('/components', {
  name: 'components',
  action() {
    BlazeLayout.render('App_body', { page: 'components' });
  },
});

import '../imports/ui/pages/components/editComponent.js';
FlowRouter.route('/components/:componentId', {
  name: 'editComponent',
  action() {
    BlazeLayout.render('App_body', { page: 'editComponent' });
  },
});

import '../imports/ui/pages/users/users.js';
FlowRouter.route('/users', {
  name: 'users',
  action() {
    BlazeLayout.render('App_body', { page: 'users' });
  },
});

import '../imports/ui/pages/users/editUser.js';
FlowRouter.route('/users/:userId', {
  name: 'editUser',
  action() {
    BlazeLayout.render('App_body', { page: 'editUser' });
  },
});

import '../imports/ui/pages/notFound/notFound.js';
FlowRouter.notFound = {
  action() {
    BlazeLayout.render('App_body', { page: 'notFound' });
  },
};

import '../imports/ui/layouts/reports/external.js';
FlowRouter.route('/reports/external/:reportIds', {
  name: 'external',
  action() {
    BlazeLayout.render('externalReport');
  },
});

import '../imports/ui/layouts/reports/internal.js';
FlowRouter.route('/reports/internal/:reportIds', {
  name: 'internal',
  action() {
    BlazeLayout.render('internalReport');
  },
});
