/*

Filename: /client/helpers.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Contains all Blaze helper functions

*/

import {permission} from '../imports/permissions.js';
import {getElement} from '../imports/elements.js';

// Helper Functions for Spacebar Templates

Template.registerHelper('equal', (a,b) => {
  return a == b;
});

Template.registerHelper('selected_if_equal', (a,b) => {
  return a == b ? "selected" : "";
});

Template.registerHelper('checked_if_equal', (a,b) => {
  return a == b ? "checked" : "";
});

Template.registerHelper('permission', (key) => {
  return permission(key);
});


Template.registerHelper('count', (cursor) => {
  return cursor.count();
});

Template.registerHelper('userId', () => {
  return Meteor.userId();
});

Template.registerHelper('users', () => {
  return Meteor.users.find({active:true},{sort:{name: 1}});
});

Template.registerHelper('getElements', (elementsObject) => {
  let elements = [];
  for(short in elementsObject){
    let element = getElement(short);
    elements.push({
      num: element[0],
      sym: element[1],
      de: element[2],
      en: element[3],
      value: elementsObject[short]
    })
  }

  return elements;
});

Template.registerHelper('getElement', (short) => {
  let element = getElement(short);
  if(element)
  return {
    num: element[0],
    sym: element[1],
    de: element[2],
    en: element[3]
  };
});

Template.registerHelper('toArray', (object) => {
  let array = [];
  for(k in object){
    array.push(object[k])
  }
  return array;
});

Template.registerHelper('toPercent', (number) => {
  if(typeof number == "number"){
    number *= 100;
    return number.toFixed(2) + " %";
  }
});

Template.registerHelper('inParentheses', (text) => {
  if(text){
    return "("+text+")";
  }
});

Template.registerHelper('date', (d = new Date()) => {
  return d.toLocaleDateString();
});

Template.registerHelper('nToBr', (text) => {
  return text && text.split ? text.split("\n").join("<br />") : "";
});
