/*

Filename: /client/main.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Client entry point, imports all client code

*/

// Define URLS (Routes) and import all Pages
import './routes.js';

// Import Layout Helper Functions
import './helpers.js';

// Subscribe myself
Meteor.subscribe("self");

// Register ServiceWorker for Chaching
var func = EventTarget.prototype.addEventListener;
EventTarget.prototype.addEventListener = function (type, fn, capture) {
    this.func = func;
    capture = capture || {};
    capture.passive = false;
    this.func(type, fn, capture);
};
if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('/service-worker.js').then(function(registration) {
    console.log('ServiceWorker registration successful!');
  }).catch(function(err) {
    console.log('ServiceWorker registration failed: ', err);
  });
}
