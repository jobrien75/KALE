/*

Filename: /imports/matchCalculation/averagedComposition.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements the match algorythem for the coefficient of determination with averaged compositions

Copyright (c) 2019 - Robert Bosch LLC

*/

import {adjustComposition, averageComposition} from '../functions.js';

export function match_AveragedComposition(search, components, excluded_elements){

  let results = {};

  components.forEach((component)=>{

    if(search.composition && component.composition){

      search.medianComposition = averageComposition(search.composition);
      component.medianComposition = averageComposition(component.composition);

      // Normalize both compositions and excluded_elements
      let search_com = adjustComposition(search.medianComposition, component.medianComposition, excluded_elements);
      let component_com = adjustComposition(component.medianComposition, search_com, excluded_elements);

      let error = 0;
      let sum = 0;
      let count = 0;

      for(element in search_com){
        let div = (component_com[element] - search_com[element]) * 100;
        error += div * div;
        count++;
        sum += component_com[element] * 100;
      }

      error = (error / count) / sum;

      if(error > 1) error = 1;

      // Match is (100 % - error)
      let match = 1 - error;

      if(!results[component._id]){
        results[component._id] = {
          search: {
            id: search._id,
            name: search.name
          },
          component: {
            id: component._id,
            name: component.name,
            product: component.product
          },
        };
      }

      if(!results[component._id].match || match > results[component._id].match){
        results[component._id].match = match;
      }

    }
  });

  return Object.values(results);
}
