/*

Filename: /imports/matchCalculation/intensity.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements the match algorythem for the intesity data

Copyright (c) 2019 - Robert Bosch LLC

*/

import {averageIntensity} from '../functions.js';

function match_intensity(search_intensity, component_intensity){
  if(!search_intensity || !component_intensity){
    return -1;
  }
  for(let i = 0; i < search_intensity.length; i++){
    search_intensity[i].y = Math.sqrt(search_intensity[i].y);
  }

  for(let i = 0; i < component_intensity.length; i++){
    component_intensity[i].y = Math.sqrt(component_intensity[i].y);
  }
  let max = 0;
  let sum = 0;
  let sum_count = 0;
  component_intensity.forEach((value)=>{
    if(value.y){

      if(value.y > max){
        max = value.y;
      }
      sum += value.y;
      sum_count++;
    }
  });

  let avg = sum / sum_count;

  let error = 0;
  let counter = 0;

  let c = 0;
  let s = 0;

  while(component_intensity[c] && search_intensity[s] && component_intensity[c+1] && search_intensity[s+1]){

    if(component_intensity[c].x == search_intensity[s].x){
      if(component_intensity[s].x > 1.2 && component_intensity[s].y > 0.5 * avg){
        let err = Math.abs(component_intensity[c].y - search_intensity[s].y);
        error += err / component_intensity[c].y;
        counter++;
      }
      s++;
      c++;
    }else if(component_intensity[c].x > search_intensity[s].x){
      s++;
    }else if(component_intensity[c].x < search_intensity[s].x){
      c++;
    }else{
      break;
    }
  }

  if(counter != 0){
    error /= counter;
  }else{
    error = 1;
  }

  if(error > 1){
    error = 1;
  }

  // Match is 100 % - error
  return 1 - error;
}


export function match_Intensity(search, components){

  let results = {};

  components.forEach((component)=>{

    if(component.intensity && search.intensity){

      let match = match_intensity(averageIntensity(search.intensity),averageIntensity(component.intensity));

      if(match == -1) return;

      if(!results[component._id]){
        results[component._id] = {
          search: {
            id: search._id,
            name: search.name
          },
          component: {
            id: component._id,
            name: component.name,
            product: component.product
          }
        };
      }

      if(!results[component._id].match || match > results[component._id].match){
        results[component._id].match = match;
      }


    }
  });

  return Object.values(results);
}
