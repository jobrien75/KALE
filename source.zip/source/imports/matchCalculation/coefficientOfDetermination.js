/*

Filename: /imports/matchCalculation/coefficientOfDetermination.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements the match algorythem for the coefficient of determination with single compositions

Copyright (c) 2019 - Robert Bosch LLC

*/

import {adjustComposition} from '../functions.js';

function match_composition(search_composition, component_composition, excluded_elements = []){

}

export function match_CoefficientOfDetermination(search, components, excluded_elements){

  let results = {};

  components.forEach((component)=>{

    if(component.composition){

      for(component_spectrum in component.composition){

        for(search_spectrum in search.composition){


          if(!search.composition[search_spectrum].elements || !component.composition[component_spectrum].elements){
            continue;
          }

          let error = 0;

          let search_com = adjustComposition(search.composition[search_spectrum].elements, component.composition[component_spectrum].elements, excluded_elements);
          let component_com = adjustComposition(component.composition[component_spectrum].elements, search_com, excluded_elements);

          let sum = 0;
          let count = 0;
          for(element in search_com){
            let div = (component_com[element] - search_com[element]) * 100;
            error += div * div;
            count++;
            sum += component_com[element] * 100;
          }

          error = (error / count) / sum;

          if(error > 1) error = 1;

          // Match is 100 % - error
          let match = 1 - error;

          if(!results[component._id]){
            results[component._id] = {
              search: {
                id: search._id,
                name: search.name
              },
              component: {
                id: component._id,
                name: component.name,
                product: component.product
              },
            };
          }

          if(!results[component._id].match || match > results[component._id].match){
            results[component._id].match = match;
            results[component._id].component.spectrum = component.composition[component_spectrum].title;
            results[component._id].search.spectrum = search.composition[search_spectrum].title;
          }
        }

      }
    }
  });

  return Object.values(results);
}
