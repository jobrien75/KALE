/*

Filename: /imports/matchCalculation/jaccardCoefficient.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements the match algorythem for jaccard coefficient

Copyright (c) 2019 - Robert Bosch LLC

*/

import {adjustComposition, minComposition, maxComposition, medianComposition, range2set, sortObject, objectAverage} from '../functions.js';

export function match_JaccardCoefficient(search, components, excluded_elements){

  let results = {};

  if(!search.composition) return [];

  search.minComposition = minComposition(search.composition);
  search.maxComposition = maxComposition(search.composition);
  search.medianComposition = medianComposition(search.composition);


  // Factor of elements is by their amount. If there are 16 elements, the element with lowest amount get 1/16, the second lowest 2/16 and so on
  let sortedSearchElements = Object.keys(sortObject(search.medianComposition));
  let elementWeightFactor = {}
  for(e = 0; e < sortedSearchElements.length; e++){
    elementWeightFactor[sortedSearchElements[e]] = (sortedSearchElements.length - e) * (1 / sortedSearchElements.length)
  }

  components.forEach((component)=>{

    if(component.composition){


      let component_minComposition = minComposition(component.composition);
      let component_maxComposition = maxComposition(component.composition);
      let component_medianComposition = medianComposition(component.composition);

      let search_minComposition = adjustComposition(search.minComposition, component_minComposition, excluded_elements);
      component_minComposition = adjustComposition(component_minComposition, search_minComposition, excluded_elements);

      let search_maxComposition = adjustComposition(search.maxComposition, component_maxComposition, excluded_elements);
      component_maxComposition = adjustComposition(component_maxComposition, search_maxComposition, excluded_elements);

      let search_medianComposition = adjustComposition(search.medianComposition, component_medianComposition, excluded_elements);
      component_medianComposition = adjustComposition(component_medianComposition, search_medianComposition, excluded_elements);

      search.sets = {};
      component.sets = {};
      let jaccardCI = 0;

      for(element in search_medianComposition){
        let search_set = range2set(search_minComposition[element],search_maxComposition[element],0.01);
        let component_set = range2set(component_minComposition[element],component_maxComposition[element],0.01);

        let intersection = search_set.filter(value => component_set.includes(value));

        let differenceMedian = Math.abs(search_medianComposition[element] - component_medianComposition[element]);

        let jaccardCoefficient = intersection.length / (search_set.length + component_set.length - intersection.length);
        let correction = (1 - differenceMedian) / (search_set.length + component_set.length - intersection.length);

         let cie = (jaccardCoefficient * 0.80 + correction * 0.20);

         if(cie < 1){
           cie *=  elementWeightFactor[element]
         }

         jaccardCI += cie;
      }

      let match = jaccardCI / Object.values(search_medianComposition).length;

      if(!results[component._id]){
        results[component._id] = {
          search: {
            id: search._id,
            name: search.name
          },
          component: {
            id: component._id,
            name: component.name,
            product: component.product
          },
        };
      }

      if(!results[component._id].match || match > results[component._id].match){
        results[component._id].match = match;
      }

    }
  });

  return Object.values(results);
}
