/*

Filename: /imports/ui/pages/products/products.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template for page products

Copyright (c) 2019 - Robert Bosch LLC

*/

import './products.html';
import './addProduct.js';

import { Products } from '../../../collections/products.js';

Template.products.onRendered(()=>{

});

Template.products.events({

});

Template.products.helpers({
  get_products(){
    return Products.find({},{
      sort:{
        name: 1,
      }
    });
  },
});
