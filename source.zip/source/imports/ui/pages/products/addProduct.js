/*

Filename: /imports/ui/pages/products/addProduct.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template addProduct

Copyright (c) 2019 - Robert Bosch LLC

*/

import './addProduct.html';

Template.addProduct.onRendered(()=>{

});

Template.addProduct.events({
  'click #open_add_product'(){
    $('#add_product').fadeIn();
    reset_inputs();
  },
  'click #add_product_abord, click #add_product_close'(){
    reset_inputs();
    $('#add_product').fadeOut();
  },
  'click #add_product_submit'(){
    let productname = $('#productname').val();

    $('#productname').removeClass("invalid");

    if(!productname){
      $('#productname').addClass("invalid");
    }else{
      Meteor.call('products.add',productname,function(err,res){
        $('#add_product').fadeOut();
        reset_inputs();
        if(!err && res){
          FlowRouter.go("/products/"+res);
        }
      });

    }
  }
});

Template.addProduct.helpers({

});

function reset_inputs(){
  $('#productname').val("").removeClass("invalid");
}
