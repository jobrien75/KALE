/*

Filename: /imports/ui/pages/products/editProduct.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template for page editProduct

Copyright (c) 2019 - Robert Bosch LLC

*/

import './editProduct.html';
import '../../components/deleteButton/deleteButton.js';
import '../../components/credentials/credentials.js';

import {permission} from '../../../permissions.js';

import { Products } from '../../../collections/products.js';

Template.editProduct.onRendered(()=>{

});

Template.editProduct.events({
  'change #name'(){
    Meteor.call('products.setName',FlowRouter.getParam('productId'),$('#name').val());
  }
});

Template.editProduct.helpers({
  get_product(){
    return Products.findOne(FlowRouter.getParam('productId'));
  },
  disabled(){
    if(!permission('editProduct')){
      return "disabled";
    }
  }
});
