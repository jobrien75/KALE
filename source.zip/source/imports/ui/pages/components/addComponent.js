/*

Filename: /imports/ui/pages/components/addComponent.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template addComponent

Copyright (c) 2019 - Robert Bosch LLC

*/

import './addComponent.html';

import { Products } from '../../../collections/products.js';

Template.addComponent.onRendered(()=>{

});

Template.addComponent.events({
  'click #open_add_component'(){
    $('#add_component').fadeIn();
    reset_inputs();
  },
  'click #add_component_abord, click #add_component_close'(){
    reset_inputs();
    $('#add_component').fadeOut();
  },
  'click #add_component_submit'(){
    let componentname = $('#componentname').val();
    let product = $('#product').val();

    $('#componentname').removeClass("invalid");

    if(!componentname){
      $('#componentname').addClass("invalid");
    }else if(!product){
      $('#product').addClass("invalid");
    }else{
      Meteor.call('components.add',componentname,product,function(err,res){
        $('#add_component').fadeOut();
        reset_inputs();
        if(res.error){
          alert(res.error);
        }else if(!err && res){
          FlowRouter.go("/components/"+res);
        }
      });

    }
  }
});

Template.addComponent.helpers({
  get_products(){
    return Products.find({},{
      sort:{
        name: 1,
      }
    });
  }
});

function reset_inputs(){
  $('#componentname').val("").removeClass("invalid");
}
