/*

Filename: /imports/ui/pages/components/editComponent.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template for page editComponent

Copyright (c) 2019 - Robert Bosch LLC

*/

import './editComponent.html';
import '../../components/deleteSpectrum/deleteSpectrum.js';
import '../../components/deleteButton/deleteButton.js';
import '../../components/credentials/credentials.js';
import '../../components/intensityChart/intensityChart.js';
import {nElements, attrFromName, averageComposition, medianComposition, stdDeviationComposition, minComposition, maxComposition} from '../../../functions.js';
import {permission} from '../../../permissions.js';
import {colorPalette} from '../../../colors.js';
import {parseCompositionXLSX, parseIntensityTXT} from '../../../parsers.js';
import {getMaterialClasses} from '../../../elements.js';

import { Components } from '../../../collections/components.js';
import { Products } from '../../../collections/products.js';

let spectra = new ReactiveVar();



Template.editComponent.onCreated(function(){
  Meteor.subscribe("components.get",FlowRouter.getParam('componentId'));
});

Template.editComponent.onRendered(function(){
  this.autorun(()=>{
    let component = Components.findOne(FlowRouter.getParam('componentId'));

    if(component && component.composition){
      let allSpectra = [];
      allSpectra.push({spectrum: "AVERAGE", componentId: component._id});
      for(let element in component.composition){
        allSpectra.push({spectrum: component.composition[element].title, componentId: component._id});
      }
      spectra.set(allSpectra);
    }else{
      spectra.set([]);
    }
  })
});

Template.editComponent.events({
  'change #name'(){
    Meteor.call('components.setName',FlowRouter.getParam('componentId'),$('#name').val());
  },
  'change #product'(){
    Meteor.call('components.setProduct',FlowRouter.getParam('componentId'),$('#product').val());
  },
  'change #analyst'(){
    Meteor.call('components.setAnalyst',FlowRouter.getParam('componentId'),$('#analyst').val());
  },
  'change #materialClass'(){
    Meteor.call('components.setMaterialClass',FlowRouter.getParam('componentId'),$('#materialClass').val());
  },
  'change #plating'(){
    Meteor.call('components.setPlating',FlowRouter.getParam('componentId'),$('#plating').val());
  },
  'change #measurementDate'(){
    let date = new Date($('#measurementDate').val().split(".").join(" "));
    if(date != "Invalid Date"){
      Meteor.call('components.setMeasurementDate',FlowRouter.getParam('componentId'),date);
    }else{
      alert("Invalid Date");
      let component = Components.findOne(FlowRouter.getParam('componentId'));
      if(component && component.measurementDate){
        $('#measurementDate').val(component.measurementDate.toLocaleDateString());
      }
    }

  },
  'change #comment'(){
    Meteor.call('components.setComment',FlowRouter.getParam('componentId'),$('#comment').val());
  },
  'change #uploadComposition'(e){
    e.preventDefault();

    $("#uploadCompositionIcon").addClass("refresh").removeClass("upload").addClass("spinning");

    let reader = new FileReader();
    reader.onload = async function(e) {
      let data = new Uint8Array(e.target.result);
      let workbook = XLSX.read(data, {type: 'array'});
      let spectra = parseCompositionXLSX(workbook);
      if(!spectra){
        alert("Parsing failed. Check the console for details.");
        return;
      }
      for(k in spectra){
        await Meteor.call('components.addComposition',FlowRouter.getParam('componentId'),spectra[k].title,spectra[k].elements,()=>{
          $("#uploadCompositionIcon").removeClass("spinning").addClass("upload").removeClass("refresh");
        });
      }
    };
    reader.readAsArrayBuffer(e.target.files[0]);
  },
  'change #uploadIntensity'(e){
    e.preventDefault();

    $("#uploadIntensityIcon").addClass("refresh").removeClass("upload").addClass("spinning");

    let count = 0;
    for(let f = 0; f < e.target.files.length; f++){
      let reader = new FileReader();
      reader.onload = function(e) {
        let data = e.target.result;
        let spectrum = parseIntensityTXT(data);
        if(!spectrum){
          alert("Parsing failed. Check the console for details.");
          return;
        }

        count++;

        Meteor.call('components.addIntensity',FlowRouter.getParam('componentId'),spectrum.title,spectrum,(err,data)=>{
          if(err){
            console.error(err);
          }
          if(data && data.error){
            alert(data.error);
          }
          if(--count == 0){
            $("#uploadIntensityIcon").removeClass("spinning").addClass("upload").removeClass("refresh");
          }
        });
      };
      reader.readAsText(e.target.files[f]);
    }
  },
  'click a.spectrum'(e){
    let componentId = FlowRouter.getParam('componentId');
    let spectrum = $(e.target).html();

    let currentSpectra = spectra.get();
    let newSpectra = [];
    let found = false;

    currentSpectra.forEach((s)=>{
      if(s.componentId && s.componentId == componentId && s.spectrum == spectrum){
        found = true;
      }else{
        newSpectra.push(s);
      }
    });
    if(!found){
      newSpectra.push({componentId,spectrum});
    }
    spectra.set(newSpectra);
  }
});

Template.editComponent.helpers({
  get_component(){
    return Components.findOne(FlowRouter.getParam('componentId'));
  },
  get_stats(){
    let stats = [];

    let component = Components.findOne(FlowRouter.getParam('componentId'));
    if(component){
      stats.push({label: "Average",   elements: averageComposition(component.composition)});
      stats.push({label: "Median",   elements: medianComposition(component.composition)});
      stats.push({label: "Std Deviation", elements: stdDeviationComposition(component.composition)});
      stats.push({label: "Minimum", elements: minComposition(component.composition)});
      stats.push({label: "Maximum", elements: maxComposition(component.composition)});
    }

    return stats;
  },
  disabled(){
    if(!permission('editComponent')){
      return "disabled";
    }
  },
  get_products(){
    return Products.find({},{
      sort:{
        name: 1,
      }
    });
  },
  get_materialClasses(){
    return getMaterialClasses();
  },
  has_intensity(spectrumTitle){
    let component = Components.findOne(FlowRouter.getParam('componentId'));
    if(component && component.intensity && component.intensity[attrFromName(spectrumTitle)]){
      return true;
    }
  },
  selected_spectra(){
    return spectra.get();
  }
});
