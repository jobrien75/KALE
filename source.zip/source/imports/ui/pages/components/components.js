/*

Filename: /imports/ui/pages/components/components.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template for page components

Copyright (c) 2019 - Robert Bosch LLC

*/

import './components.html';
import './addComponent.js';

import { Components } from '../../../collections/components.js';
import { Products } from '../../../collections/products.js';
import { getMaterialClasses } from '../../../elements.js';

let search = new ReactiveVar("");
let productFilter = new ReactiveVar("all");
let materialClassFilter = new ReactiveVar("all");

Template.components.onRendered(()=>{

});

Template.components.events({
  'keyup #search'(){
    search.set($('#search').val());
  },
  'change #selectProduct'(){
    productFilter.set($('#selectProduct').val());
  },
  'change #selectMaterialClass'(){
    materialClassFilter.set($('#selectMaterialClass').val());
  },
});

Template.components.helpers({
  get_components(){

    let components = [];

    let filter = {};
    let product = productFilter.get();
    if(product && product != "all"){
      filter.product = product;
    }
    let materialClass = materialClassFilter.get();
    if(materialClass && materialClass != "all"){
      filter.materialClass = materialClass;
    }
    Components.find(filter,{
      sort:{
        name: 1,
      },
      fields: {
        name: 1,
        product: 1,
        materialClass: 1,
      }
    }).forEach((component)=>{
      let componentName_contains_searchString = true;

      //split search against each word
      if(search.get() != ""){
        search.get().split(" ").forEach((search)=>{

          // if I replace the searchtext in the name, than the name should be different from before replacing
          // to lowerCase for lazy lowercase search
          if(component.name.toLowerCase().replace(search.toLowerCase()) == component.name.toLowerCase()){
            componentName_contains_searchString = false;
          }

        })
      }

      if(componentName_contains_searchString){
        components.push(component);
      }
    })

    return components;
  },
  get_materialClasses(){
    return getMaterialClasses();
  },
  get_products(){
    return Products.find({},{
      sort:{
        name: 1,
      }
    });
  },
  search(){
    return search.get();
  },
  productFilter(){
    return productFilter.get();
  },
  materialClassFilter(){
    return materialClassFilter.get();
  },
  get_productName(productId){
    let product = Products.findOne(productId);
    if(product && product.name){
      return product.name;
    }
  },
});
