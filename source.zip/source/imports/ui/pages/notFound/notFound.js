/*

Filename: /imports/ui/pages/notFound/notFound.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template for page notFound

Copyright (c) 2019 - Robert Bosch LLC

*/

import './notFound.html';

Template.notFound.onRendered(function(){

});

Template.notFound.events({

});

Template.notFound.helpers({

});
