/*

Filename: /imports/ui/pages/projects/editProject.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template for page editProject

Copyright (c) 2019 - Robert Bosch LLC

*/

import './projects.html';
import './addProject.js';

import { Projects } from '../../../collections/projects.js';

let search = new ReactiveVar("");
let userFilter = new ReactiveVar(Meteor.userId());
let ageFilter = new ReactiveVar(1000 * 60 * 60 * 24 * 14);

Template.projects.onRendered(()=>{

});

Template.projects.events({
  'keyup #search'(){
    search.set($('#search').val());
  },
  'change #selectUser'(){
    userFilter.set($('#selectUser').val());
  },
  'change #selectAge'(){
    ageFilter.set($('#selectAge').val());
  },
});

Template.projects.helpers({
  get_projects(){
    let products = [];

    let filter = {};
    if(userFilter.get() != "all"){
      filter.owner = userFilter.get()
    }
    if(ageFilter.get() != "all"){
      filter["created.at"] = {$gt: new Date(new Date() - ageFilter.get())};
    }
    Projects.find(filter,{
      sort:{
        "created.at": -1,
        "name": 1
      }
    }).forEach((product)=>{
      let productName_contains_searchString = true;

      //split search against each word
      if(search.get() != ""){
        search.get().split(" ").forEach((search)=>{

          // if I replace the searchtext in the name, than the name should be different from before replacing
          // to lowerCase for lazy lowercase search
          if(product.name.toLowerCase().replace(search.toLowerCase()) == product.name.toLowerCase()){
            productName_contains_searchString = false;
          }
        })
      }

      if(productName_contains_searchString){
        products.push(product);
      }

    })
    return products;
  },
  getDurations(){
    let durations = [];

    let day = 24 * 60 * 60 * 1000;
    let week = 7 * day;
    let month = 30 * day;
    let year = 360 * day;

    durations.push({name: "1 Week", time: week});
    durations.push({name: "2 Weeks", time: 2 * week});
    durations.push({name: "1 Month", time: month});
    durations.push({name: "3 Months", time: 3 * month});
    durations.push({name: "1 Year", time: year});

    return durations;
  },
  search(){
    return search.get();
  },
  userFilter(){
    return userFilter.get();
  },
  ageFilter(){
    return ageFilter.get();
  }
});
