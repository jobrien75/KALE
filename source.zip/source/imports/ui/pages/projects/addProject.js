/*

Filename: /imports/ui/pages/projects/addProject.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template addProject

Copyright (c) 2019 - Robert Bosch LLC

*/

import './addProject.html';

Template.addProject.onRendered(()=>{

});

Template.addProject.events({
  'click #open_add_project'(){
    $('#add_project').fadeIn();
    reset_inputs();
  },
  'click #add_project_abord, click #add_project_close'(){
    reset_inputs();
    $('#add_project').fadeOut();
  },
  'click #add_project_submit'(){
    let projectname = $('#projectname').val();

    $('#projectname').removeClass("invalid");

    if(!projectname){
      $('#projectname').addClass("invalid");
    }else{
      Meteor.call('projects.add',projectname,function(err,res){
        $('#add_project').fadeOut();
        reset_inputs();
        if(!err && res){
          FlowRouter.go("/projects/"+res);
        }
      });

    }
  }
});

Template.addProject.helpers({

});

function reset_inputs(){
  $('#projectname').val("").removeClass("invalid");
}
