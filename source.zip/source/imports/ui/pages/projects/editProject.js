/*

Filename: /imports/ui/pages/projects/editProject.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template for page editProject

Copyright (c) 2019 - Robert Bosch LLC

*/

import './editProject.html';
import './mergeReports.js';
import '../searches/addSearch.js';
import '../../components/deleteButton/deleteButton.js';
import '../../components/credentials/credentials.js';

import {permission} from '../../../permissions.js';

import { Projects } from '../../../collections/projects.js';
import { Searches } from '../../../collections/searches.js';
import { Reports } from '../../../collections/reports.js';

Template.editProject.onRendered(()=>{

});

Template.editProject.events({
  'change #name'(){
    Meteor.call('projects.setName',FlowRouter.getParam('projectId'),$('#name').val());
  },
  'change #owner'(){
    Meteor.call('projects.setOwner',FlowRouter.getParam('projectId'),$('#owner').val());
  },
  'change #addParticipant'(){
    Meteor.call('projects.addParticipant',FlowRouter.getParam('projectId'),$('#addParticipant').val(),()=>$('#addParticipant').val("none"));

  },

});

Template.editProject.helpers({
  get_project(){
    return Projects.findOne(FlowRouter.getParam('projectId'));
  },
  get_participants(){
    let project = Projects.findOne(FlowRouter.getParam('projectId'));
    if(project.participants){
      let participants = [];
      project.participants.forEach((userId)=>{
        let user = Meteor.users.findOne(userId);
        if(user){
          participants.push({
            id: user._id,
            name: user.name
          });
        }

      });
      return participants;
    }
  },
  disabled(){
    if(!permission('editProject')){
      return "disabled";
    }
  },
  get_searches(){
    let searches = [];
    Searches.find({project: FlowRouter.getParam('projectId')},{
      sort:{
        "name": 1
      },
      fields: {
        name: 1,
        mainElement: 1,
        project: 1,
        created: 1
      }
    }).forEach((search)=>{
      let report = Reports.findOne({searchId: search._id});
      if(report){
        searches.push({...search, report: report._id})
      }else{
        searches.push(search);
      }
    });
    return searches;
  },
});
