/*

Filename: /imports/ui/pages/projects/mergeReports.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template mergeReports

Copyright (c) 2019 - Robert Bosch LLC

*/

import './mergeReports.html';

import { Projects } from '../../../collections/projects.js';
import { Searches } from '../../../collections/searches.js';
import { Reports } from '../../../collections/reports.js';

Template.mergeReports.onRendered(()=>{

});

Template.mergeReports.events({
  'click #open_mergeReports'(){
    $('#mergeReports').fadeIn();
  },
  'click #mergeReports_abord, click #mergeReports_close'(){
    $('#mergeReports').fadeOut();
  },
  'click #mergeReports_internal'(){
    window.open('/reports/internal/'+mergeReports(), '_blank');
  },
  'click #mergeReports_external'(){
    window.open('/reports/external/'+mergeReports(), '_blank');
  }
});

function mergeReports(){
  let reports = [];
  document.querySelectorAll('.reportId:checked').forEach((node)=>{
      reports.push(node.value);
  });
  return reports.join(",");
}

Template.mergeReports.helpers({
  get_searches(){
    let searches = [];
    Searches.find({project: FlowRouter.getParam('projectId')},{
      sort:{
        "name": 1,
      },
      fields: {
        name: 1
      }
    }).forEach((search)=>{
      let report = Reports.findOne({searchId: search._id});
      if(report){
        searches.push({...search, report: report._id})
      }else{
        searches.push(search);
      }
    });
    return searches;
  },
  disabled_checked(report){
    if(report){
      return "checked";
    }else{
      return "disabled";
    }
  }
});
