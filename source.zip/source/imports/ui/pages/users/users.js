/*

Filename: /imports/ui/pages/users/users.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template for page users

Copyright (c) 2019 - Robert Bosch LLC

*/

import './users.html';
import './addUser.js';

Template.users.onRendered(()=>{

});

Template.users.events({

});

Template.users.helpers({
  get_users(){
    return Meteor.users.find({},{
      sort:{
        active: -1,
        name: 1,
      }
    });
  }
});
