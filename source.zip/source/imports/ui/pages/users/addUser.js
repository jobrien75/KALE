/*

Filename: /imports/ui/pages/users/addUser.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template addUser

Copyright (c) 2019 - Robert Bosch LLC

*/

import './addUser.html';

Template.addUser.onRendered(()=>{

});

Template.addUser.events({
  'click #open_add_user'(){
    $('#add_user').fadeIn();
    reset_inputs();
  },
  'click #add_user_abord, click #add_user_close'(){
    reset_inputs();
    $('#add_user').fadeOut();
  },
  'click #add_user_submit'(){
    let name = $('#name').val();
    let department = $('#department').val();

    $('#name').removeClass("invalid");

    if(!name){
      $('#name').addClass("invalid");
    }else{
      Meteor.call('users.add',name,department,function(err,res){
        $('#add_user').fadeOut();
        reset_inputs();
        if(res == "username_exists"){
          alert("Username already exists");
        }else if(res == "username_empty"){
          alert("Username should not be empty");
        }else if(!err && res){
          FlowRouter.go("/users/"+res);
        }
      });

    }
  }
});

Template.users.helpers({

});

function reset_inputs(){
  $('#name').val("").removeClass("invalid");
}
