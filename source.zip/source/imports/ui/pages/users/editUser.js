/*

Filename: /imports/ui/pages/users/editUser.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template for page editUser

Copyright (c) 2019 - Robert Bosch LLC

*/

import './editUser.html';

import '../../components/deleteButton/deleteButton.js';
import {permission,get_permissions} from '../../../permissions.js';

Template.editUser.onRendered(()=>{

});

Template.editUser.events({
  'change #name'(){
    Meteor.call('users.setName',FlowRouter.getParam('userId'),$('#name').val());
  },
  'change #username'(){
    Meteor.call('users.setUsername',FlowRouter.getParam('userId'),$('#username').val(),(res)=>{
      if(res == "username_exists"){
        alert("Username already exists");
      }
      if(res == "username_empty"){
        alert("Username should not be empty");
      }
    });
  },
  'change #department'(){
    Meteor.call('users.setDepartment',FlowRouter.getParam('userId'),$('#department').val());
  },
  'click #changePassword'(){
    let currentPassword = $('#currentPassword').val();
    let newPassword = $('#newPassword').val();
    let newPassword2 = $('#newPassword2').val();
    if (newPassword != newPassword2){
      alert("New passwords do not match");
    }else{
      Accounts.changePassword(currentPassword, newPassword, (err)=>{
        if(err){
          alert(err.reason);
        }else{
          alert("Password changed");
          $('#currentPassword').val("");
          $('#newPassword').val("");
          $('#newPassword2').val("");
        }
      });
    }
  },
  'change #active'(e){
    let active = $('#active:checked').length != 0;
    Meteor.call('users.setActive',FlowRouter.getParam('userId'),active);
  },
  'change .permission'(e){
    let permissions = [];
    document.querySelectorAll('.permission:checked').forEach((node)=>{
        permissions.push(node.value);
    });
    Meteor.call('users.setPermission',FlowRouter.getParam('userId'),permissions,(res)=>{
      if(res == "self_editing_not_allowed"){
        alert("You cannot edit your permissions.");
      }
      if(res == "not_enought_permissions"){
        alert("You don't have the permissions.");
      }
    })
  },
  'click #resetPassword'(e){
    e.preventDefault();
    Meteor.call('users.resetPassword',FlowRouter.getParam('userId'),(err,res)=>{
      if(res && !err){
        alert("New Password is: "+res);
      }
    });
  }
});

Template.editUser.helpers({
  get_user(){
    return Meteor.users.findOne(FlowRouter.getParam('userId'));
  },
  get_permissions(){

    let permissions = get_permissions();

    let user = Meteor.users.findOne(FlowRouter.getParam('userId'));
    if(!user) return;

    for(n in permissions){
      if(user.permission && user.permission.includes(permissions[n].key)){
        permissions[n].checked = 'checked';
      }
      if(!permission("editUserPermissons") || user._id == Meteor.userId()){
        permissions[n].disabled = 'disabled';
      }
    }
    return permissions;
  },
  disabled_by_permission(){
    return permission("editUser") ? "" : "disabled";
  }
});
