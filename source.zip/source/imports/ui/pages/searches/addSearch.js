/*

Filename: /imports/ui/pages/searches/addSearch.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template addSearch

Copyright (c) 2019 - Robert Bosch LLC

*/

import './addSearch.html';

import { Projects } from '../../../collections/projects.js';

Template.addSearch.onRendered(()=>{

});

Template.addSearch.events({
  'click #open_add_search'(){
    $('#add_search').fadeIn();
    reset_inputs();
  },
  'click #add_search_abord, click #add_search_close'(){
    reset_inputs();
    $('#add_search').fadeOut();
  },
  'click #add_search_submit'(){
    let particle = $('#newparticle').val();
    let project = $('#newproject').val();
    let description = $('#newdescription').val();

    $('#newparticle').removeClass("invalid");
    $('#newproject').removeClass("invalid");

    if(!particle){
      $('#newparticle').addClass("invalid");
    }else if(!project){
      $('#newproject').addClass("invalid");
    }else{
      Meteor.call('searches.add',particle,project,description,function(err,res){
        $('#add_search').fadeOut();
        reset_inputs();
        if(!err && res){
          FlowRouter.go("/searches/"+res);
        }
      });

    }
  }
});

Template.addSearch.helpers({
  get_projects(){
    return Projects.find({},{
      sort:{
        name: 1,
      }
    });
  },
  projectId(){
    return FlowRouter.getParam('projectId');
  }
});

function reset_inputs(){
  $('#newparticle').val("").removeClass("invalid");
}
