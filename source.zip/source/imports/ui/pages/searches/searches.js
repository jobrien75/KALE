/*

Filename: /imports/ui/pages/searches/editSearch.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template for page editSearch

Copyright (c) 2019 - Robert Bosch LLC

*/

import './searches.html';
import './addSearch.js';

import { Searches } from '../../../collections/searches.js';
import { Projects } from '../../../collections/projects.js';
import { Reports } from '../../../collections/reports.js';

let projectFilter = new ReactiveVar();

Template.searches.onRendered(()=>{
});

Template.searches.events({
  'change #selectProject'(){
    projectFilter.set($('#selectProject').val());
  }
});

Template.searches.helpers({
  get_searches(){
    let project = projectFilter.get();
    let filter = {};
    if(project && project != "all"){
      filter = {project};
    }
    let searches = [];
    Searches.find(filter,{
      sort:{
        "created.at": -1,
      },
      fields: {
        name: 1,
        mainElement: 1,
        project: 1,
        created: 1
      }
    }).forEach((search)=>{
      let report = Reports.findOne({searchId: search._id});
      if(report){
        searches.push({...search, report: report._id})
      }else{
        searches.push(search);
      }
    });
    return searches;
  },
  get_projects(){
    return Projects.find({},{
      sort:{
        name: 1,
      }
    });
  },
  projectFilter(){
    return projectFilter.get()
  },
  get_projectName(projectId){
    let project = Projects.findOne(projectId);
    if(project && project.name){
      return project.name;
    }
  },
});
