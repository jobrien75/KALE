/*

Filename: /imports/ui/pages/searches/compareSearch.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template for page compareSearch

Copyright (c) 2019 - Robert Bosch LLC

*/

import './compareSearch.html';
import '../../components/compositionChart/compositionChart.js';
import '../../components/loader/loader.js';

import {nElements,attrFromName,sortObject,averageComposition,variationComposition} from '../../../functions.js';
import {permission} from '../../../permissions.js';
import {colorPalette} from '../../../colors.js';
import {parseCompositionXLSX, parseIntensityTXT} from '../../../parsers.js';
import {getMaterialClasses} from '../../../elements.js';
import {matchAlgorithms} from '../../../matchCalculation.js';

import { Searches } from '../../../collections/searches.js';
import { Components } from '../../../collections/components.js';
import { Products } from '../../../collections/products.js';

let results = new ReactiveVar([]);
let spectra = new ReactiveVar([]);

let selectMaterialClass = new ReactiveVar("all",triggerGetMatches);
let selectProduct = new ReactiveVar("all",triggerGetMatches);
let algorithm = new ReactiveVar("default",triggerGetMatches);
let minMatch = new ReactiveVar(0.8,triggerGetMatches);
let nResults = new ReactiveVar(10,triggerGetMatches);

let excluded_elements = new ReactiveVar([],triggerGetMatches);

let loading = new ReactiveVar(false);

function triggerGetMatches(a,b){
  loading.set("results");
  setTimeout(getMatches,1);
  return a === b;
}

Template.compareSearch.onCreated(function() {
  Meteor.subscribe("searches.get",FlowRouter.getParam('searchId'),()=>{
    let search = Searches.findOne(FlowRouter.getParam('searchId'));

    if(search){
      selectMaterialClass.set(search.materialClass);
    }
  });
});

Template.compareSearch.events({
  'change #conclusion'(){
    Meteor.call('searches.setConclusion',FlowRouter.getParam('searchId'),$('#conclusion').val());
  },
  'click #externalReport'(){
    $("#externalReportIcon").addClass("refresh").removeClass("document").addClass("spinning");
    Meteor.call('reports.add',FlowRouter.getParam('searchId'), results.get().slice(0, 10), excluded_elements.get(), (err,data)=>{
      $("#externalReportIcon").removeClass("spinning").addClass("document").removeClass("refresh");

      if(!err && data){
        window.open('/reports/external/'+data, '_blank');
      }
    });
  },
  'click #internalReport'(){
    $("#internalReportIcon").addClass("refresh").removeClass("document").addClass("spinning");
    Meteor.call('reports.add',FlowRouter.getParam('searchId'), results.get().slice(0, 10), excluded_elements.get(), (err,data)=>{
      $("#internalReportIcon").removeClass("spinning").addClass("document").removeClass("refresh");

      if(!err && data){
        window.open('/reports/internal/'+data, '_blank');
      }
    });
  },
  'change #selectProduct'(){
    selectProduct.set($("#selectProduct").val());
  },
  'change #selectMaterialClass'(){
    selectMaterialClass.set($("#selectMaterialClass").val());
  },
  'change #selectAlgorithm'(){
    algorithm.set($("#selectAlgorithm").val());
  },
  'change #selectMinMatch'(){
    minMatch.set($("#selectMinMatch").val());
  },
  'change #selectNResults'(){
    nResults.set($("#selectNResults").val());
  },
});

Template.compareSearch.helpers({
  get_search(){
    return Searches.findOne(FlowRouter.getParam('searchId'));
  },
  get_component(componentId){
    return Components.findOne(componentId,{
      fields: {
        measurementDate: 1,
        plating: 1,
        comment: 1,
        product: 1
      }
    });
  },
  get_results(){
    return results.get();
  },
  get_TableHead(){

    let search = Searches.findOne(FlowRouter.getParam('searchId'));
    if(!search) return;
    let elements = sortObject(averageComposition(search.composition));

    return Object.keys(elements);

  },
  get_TableRows(){



    let search = Searches.findOne(FlowRouter.getParam('searchId'));
    if(!search) return [];

    let searchElements = sortObject(averageComposition(search.composition, 2));
    let variationElements = variationComposition(search.composition, 2);
    let elements = [];

    // If wanted to limit the number of elements: searchElements = limitObject(searchElements, 8);
    for(e in searchElements){
      elements.push({label: e, avg: searchElements[e], var: variationElements[e]});
    }

    let rows = [];

    rows.push({match: false, title: search.name, elements});

    let the_results = results.get();
    if(the_results){
      the_results = the_results.sort((a,b)=>{
        return b.match - a.match;
      })

      for(r in the_results){

        let component = Components.findOne(the_results[r].component.id);
        if(!component) continue;

        let componentElements = averageComposition(component.composition, 2);
        let variationElements = variationComposition(component.composition, 2);
        let elements = [];

        for(e in searchElements){
          elements.push({label: e, avg: componentElements[e], var: variationElements[e]});
        }

        rows.push({match: the_results[r].match, title: the_results[r].component.name, component_id: the_results[r].component.id, measurementDate: component.measurementDate, elements})
      }
    }

    return rows;
  },
  get_products(){
    return Products.find({},{
      sort:{
        name: 1,
      }
    });
  },
  get_materialClasses(){
    return getMaterialClasses();
  },
  get_algorithms(){
    return matchAlgorithms();
  },
  get_MinMatchs(){
    return [0.95, 0.9, 0.85, 0.8, 0.75, 0.5, 0.25, 0];
  },
  get_NResults(){
    return [1, 3, 5, 7, 10, 20, 50];
  },
  filter(){
    return {
      materialClass: selectMaterialClass.get(),
      product: selectProduct.get(),
      algorithm: algorithm.get(),
      minMatch: minMatch.get(),
      nResults: nResults.get()
    }
  },
  product_name(productId){
    return Products.findOne({_id: productId}).name;
  },
  result_spectra(){
    return spectra.get();
  },
  reactive_excluded_elements(){
    return excluded_elements;
  },
  indexToRank(index){
    return index + 1;
  },
  componentDate(componentId){
    let component = Components.findOne(componentId);
    if(component && component.measurementDate){
      return component.measurementDate;
    }else if(component){
      return component.created.at;
    }
  },
  componentPlating(componentId){
    let component = Components.findOne(componentId);
    if(component && component.plating){
      return component.plating;
    }
  },
  disabled(){
    return permission("createReport") ? "" : "disabled";
  },
  loading(){
    return loading.get();
  }
});

function getMatches(){
  Meteor.call('searches.compare',FlowRouter.getParam('searchId'),algorithm.get(),excluded_elements.get(),nResults.get(),minMatch.get(),selectProduct.get(),selectMaterialClass.get(),(err,matches)=>{
    if(!matches || err){
      console.error(err);
      return;
    }
    console.log({matches})
    let search = Searches.findOne(FlowRouter.getParam('searchId'));

    let result_spectra = [{
      searchId: search._id,
      spectrum: "AVERAGE"
    }];

    let componentIds = [];

    matches.forEach((match)=>{
      result_spectra.push({
        componentId: match.component.id,
        spectrum: "AVERAGE"
      })
      componentIds.push(match.component.id);
    })

    Meteor.subscribe('components.composition', componentIds,()=>{
      spectra.set(result_spectra);
      results.set(matches);
      loading.set(false);
    });
  });
}
