/*

Filename: /imports/ui/pages/searches/editSearch.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template for page editSearch

Copyright (c) 2019 - Robert Bosch LLC

*/

import './editSearch.html';
import '../../components/deleteSpectrum/deleteSpectrum.js';
import '../../components/deleteButton/deleteButton.js';
import '../../components/credentials/credentials.js';
import '../../components/intensityChart/intensityChart.js';
import {nElements, attrFromName, averageComposition, medianComposition, stdDeviationComposition, minComposition, maxComposition} from '../../../functions.js';
import {getMaterialClasses} from '../../../elements.js';
import {permission} from '../../../permissions.js';
import {colorPalette} from '../../../colors.js';
import {parseCompositionXLSX, parseIntensityTXT, compressTiffToJPEG} from '../../../parsers.js';

import { Searches } from '../../../collections/searches.js';
import { Projects } from '../../../collections/projects.js';
import { Components } from '../../../collections/components.js';
import { Products } from '../../../collections/products.js';
import { Images } from '../../../collections/images.js';

let selectSpectra = new ReactiveVar();

Template.editSearch.onCreated(function(){
  Meteor.subscribe("searches.get",FlowRouter.getParam('searchId'));
  Meteor.subscribe("images.searchId",FlowRouter.getParam('searchId'));
});


Template.editSearch.onRendered(function(){
  this.autorun(()=>{
    let search = Searches.findOne(FlowRouter.getParam('searchId'));

    if(search && search.composition){
      let allSpectra = [];
      allSpectra.push({spectrum: "AVERAGE", searchId: search._id});
      for(let element in search.composition){
        allSpectra.push({spectrum: search.composition[element].title, searchId: search._id});
      }
      selectSpectra.set(allSpectra);
    }else{
      selectSpectra.set([]);
    }
  })

});

Template.editSearch.events({
  'change #name'(){
    Meteor.call('searches.setName',FlowRouter.getParam('searchId'),$('#name').val());
  },
  'change #project'(){
    Meteor.call('searches.setProject',FlowRouter.getParam('searchId'),$('#project').val());
  },
  'change #analyst'(){
    Meteor.call('searches.setAnalyst',FlowRouter.getParam('searchId'),$('#analyst').val());
  },
  'change #materialClass'(){
    Meteor.call('searches.setMaterialClass',FlowRouter.getParam('searchId'),$('#materialClass').val());
  },
  'change #instrument'(){
    Meteor.call('searches.setInstrument',FlowRouter.getParam('searchId'),$('#instrument').val());
  },
  'change #measurementDate'(){
    let date = new Date($('#measurementDate').val().split(".").join(" "));
    if(date != "Invalid Date"){
      Meteor.call('searches.setMeasurementDate',FlowRouter.getParam('searchId'),date);
    }else{
      alert("Invalid Date");
      let search = Searches.findOne(FlowRouter.getParam('searchId'));
      if(search && search.measurementDate){
        $('#measurementDate').val(search.measurementDate.toLocaleDateString());
      }
    }
  },
  'change #description'(){
    Meteor.call('searches.setDescription',FlowRouter.getParam('searchId'),$('#description').val());
  },
  'change #uploadComposition'(e){
    e.preventDefault();

    $("#uploadCompositionIcon").addClass("refresh").removeClass("upload").addClass("spinning");


    let reader = new FileReader();
    reader.onload = async function(e) {
      let data = new Uint8Array(e.target.result);
      let workbook = XLSX.read(data, {type: 'array'});
      let spectras = parseCompositionXLSX(workbook);
      if(!spectras){
        alert("Parsing failed. Check the console for details.");
        return;
      }
      for(k in spectras){
        await Meteor.call('searches.addComposition',FlowRouter.getParam('searchId'),spectras[k].title,spectras[k].elements,(err,data)=>{
          $("#uploadCompositionIcon").removeClass("spinning").addClass("upload").removeClass("refresh");
        });
      }
    };
    reader.readAsArrayBuffer(e.target.files[0]);
  },
  'change #uploadIntensity'(e){
    e.preventDefault();

    $("#uploadIntensityIcon").addClass("refresh").removeClass("upload").addClass("spinning");

    let count = 0;
    for(let f = 0; f < e.target.files.length; f++){
      let reader = new FileReader();
      reader.onload = function(e) {
        let data = e.target.result;
        let spectrum = parseIntensityTXT(data);
        if(!spectrum){
          alert("Parsing failed. Check the console for details.");
          return;
        }

        count++;

        Meteor.call('searches.addIntensity',FlowRouter.getParam('searchId'),spectrum.title,spectrum,(err,data)=>{
          if(err){
            console.error(err);
          }
          if(data && data.error){
            alert(data.error);
          }
          if(--count == 0){
            $("#uploadIntensityIcon").removeClass("spinning").addClass("upload").removeClass("refresh");
          }
        });
      };
      reader.readAsText(e.target.files[f]);
    }
  },
  'change #uploadImage'(e){
    e.preventDefault();

    $("#uploadImageIcon").addClass("refresh").removeClass("upload").addClass("spinning");


    let reader = new FileReader();
    reader.onload = function(e) {
      let data = e.target.result;

      if(data.byteLength > 10*1024*1024){
        alert("Image is to big. Max. 10 MB");
        return;
      }

      let jpegBase64 = compressTiffToJPEG(data, 0.7);
      if(!jpegBase64){
        alert("Converting failed. Check the console for details.");
        return;
      }

      Meteor.call('images.addSearchImage',FlowRouter.getParam('searchId'),jpegBase64,(err,data)=>{
        $("#uploadImageIcon").removeClass("spinning").addClass("upload").removeClass("refresh");

        if(err){
          console.error(err);
        }
        if(data && data.error){
          alert(data.error);
        }
      });
    };
    reader.readAsArrayBuffer(e.target.files[0]);
  },
  'click a.spectrum'(e){
    let searchId = FlowRouter.getParam('searchId');
    let spectrum = $(e.target).html();

    let currentSpectra = selectSpectra.get();
    let newSpectra = [];
    let found = false;

    currentSpectra.forEach((s)=>{
      if(s.searchId && s.searchId == searchId && s.spectrum == spectrum){
        found = true;
      }else{
        newSpectra.push(s);
      }
    });
    if(!found){
      newSpectra.push({searchId,spectrum});
    }
    selectSpectra.set(newSpectra);
  }
});

Template.editSearch.helpers({
  get_search(){
    return Searches.findOne(FlowRouter.getParam('searchId'));
  },
  get_stats(){
    let stats = [];

    let search = Searches.findOne(FlowRouter.getParam('searchId'));
    if(search){
      stats.push({label: "Average",   elements: averageComposition(search.composition)});
      stats.push({label: "Median",   elements: medianComposition(search.composition)});
      stats.push({label: "Std Deviation", elements: stdDeviationComposition(search.composition)});
      stats.push({label: "Minimum", elements: minComposition(search.composition)});
      stats.push({label: "Maximum", elements: maxComposition(search.composition)});
    }

    return stats;
  },
  get_materialClasses(){
    return getMaterialClasses();
  },
  disabled(){
    if(!permission('editSearch')){
      return "disabled";
    }
  },
  get_projects(){
    return Projects.find({},{
      sort:{
        name: 1,
      }
    });
  },
  has_intensity(spectrumTitle){
    let search = Searches.findOne(FlowRouter.getParam('searchId'));
    if(search && search.intensity && search.intensity[attrFromName(spectrumTitle)]){
      return true;
    }
  },
  jpegBase64(){
    let image = Images.findOne({searchId: FlowRouter.getParam('searchId')});
    if(image && image.jpegBase64){
      return image.jpegBase64;
    }
  },
  selected_spectra(){
    return selectSpectra.get();
  }
});
