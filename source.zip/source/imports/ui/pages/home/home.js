/*

Filename: /imports/ui/pages/home/home.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template for page home

Copyright (c) 2019 - Robert Bosch LLC

*/

import './home.html';

import { Searches } from '../../../collections/searches.js';
import { Projects } from '../../../collections/projects.js';
import { Reports } from '../../../collections/reports.js';

Template.home.onRendered(()=>{

});

Template.home.events({

});

Template.home.helpers({
  get_projects(){
    let projects = [];
    Projects.find({
      $or: [
        {'owner': Meteor.userId()},
        {'participants': Meteor.userId()},
        {'created.from': Meteor.userId()},
        {'changed.from': Meteor.userId()}
      ]
    },{
      sort:{
        "changed.at": -1,
        "created.at": -1,
        "name": 1
      },
      fields: {
        name: 1,
        changed: 1
      },
      limit: 10
    }).forEach((project)=>{
      let reports = [];
      Searches.find({project: project._id},{fields:{}}).forEach((search)=>{
        let report = Reports.findOne({searchId: search._id},{fields:{}});
        if(report){
          reports.push(report._id);
        }
      });
      if(reports.length){
        projects.push({...project, report: reports.join(",")})
      }else{
        projects.push(project);
      }
    });

    return projects;
  },
  get_searches(){

    let searches = [];
    Searches.find({
      $or: [
        {'analyst': Meteor.userId()},
        {'created.from': Meteor.userId()},
        {'changed.from': Meteor.userId()}
      ]
    },{
      sort:{
        "changed.at": -1,
        "name": 1
      },
      fields: {
        name: 1,
        mainElement: 1,
        project: 1,
        changed: 1
      },
      limit: 10
    }).forEach((search)=>{
      let report = Reports.findOne({searchId: search._id});
      if(report){
        searches.push({...search, report: report._id})
      }else{
        searches.push(search);
      }
    });

    return searches;
  },
  userName(){
    return Meteor.user().name;
  },
  get_projectName(projectId){
    let project = Projects.findOne(projectId);
    if(project && project.name){
      return project.name;
    }
  },
});
