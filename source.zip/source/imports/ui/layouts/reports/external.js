/*

Filename: /imports/ui/layouts/reports/external.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Layout external report

Copyright (c) 2019 - Robert Bosch LLC

*/

import './external.html';
import '../../components/loader/loader.js';
let subscriptionState = new ReactiveVar();

import { Reports } from '../../../collections/reports.js';
import { Searches } from '../../../collections/searches.js';
import { Images } from '../../../collections/images.js';
import { getStatus } from '../../../colors.js';

Template.externalReport.onRendered(function(){
  Tracker.autorun(()=>{
    if(!FlowRouter.getParam('reportIds')) return;
    let ids = FlowRouter.getParam('reportIds').split(",");
    subscriptionState.set("reports");
    Meteor.subscribe("reports.get",ids,()=>{
      Reports.find({ _id: {$in: ids}}).forEach((report)=>{
        if(report && report.imageId){
          subscriptionState.set("images");
          Meteor.subscribe("images.get",report.imageId,()=>{
            subscriptionState.set("done");
          });
        }
      });
    });
  })
});

Template.externalReport.events({
  'click #print'(){
    alert("Make sure that you print in portrait mode");
    window.print();
  },
  'click #copy'(){
    const el = document.createElement('textarea');  // Create a <textarea> element
    el.value = window.location.href;                // Set its value to the URL that you want copied
    el.setAttribute('readonly', '');                // Make it readonly to be tamper-proof
    el.style.position = 'absolute';
    el.style.left = '-9999px';                      // Move outside the screen to make it invisible
    document.body.appendChild(el);                  // Append the <textarea> element to the HTML document
    const selected =
      document.getSelection().rangeCount > 0        // Check if there is any content selected previously
        ? document.getSelection().getRangeAt(0)     // Store selection if found
        : false;                                    // Mark as false to know no selection existed before
    el.select();                                    // Select the <textarea> content
    document.execCommand('copy');                   // Copy - only works as a result of a user action (e.g. click events)
    document.body.removeChild(el);                  // Remove the <textarea> element
    if (selected) {                                 // If a selection existed before copying
      document.getSelection().removeAllRanges();    // Unselect everything on the HTML document
      document.getSelection().addRange(selected);   // Restore the original selection
    }
  }
});

Template.externalReport.helpers({
  subscriptionState(){
    return subscriptionState.get();
  },
  get_reports(){
    let reports = [];

    let ids = FlowRouter.getParam('reportIds').split(",");
    Reports.find({ _id: {$in: ids}},{sort:{"search.name": 1}}).forEach((report)=>{
      report.results = report.results.sort((a,b)=>{
        return b.originalMatch - a.originalMatch;
      })

      for(r in report.results){
        report.results[r].status = getStatus(report.results[r].match);
        report.results[r].match = Math.floor(report.results[r].match * 100) + " %";
      }
      reports.push(report);
    })
    return reports;
  },
  reportIds(){
    return FlowRouter.getParam('reportIds');
  },
  searchId(){
    let ids = FlowRouter.getParam('reportIds').split(",");
    if(ids.length == 1){
      let report = Reports.findOne(ids[0]);
      if(report && report.searchId){
        return report.searchId;
      }
    }
    return false;
  },
  projectId(){
    let ids = FlowRouter.getParam('reportIds').split(",");
    if(ids.length > 1){
      let report = Reports.findOne(ids[0]);
      if(report){
        let search = Searches.findOne(report.searchId)
        if(search && search.project){
          return search.project;
        }
      }
    }
    return false;
  },
  get_image_src(reportId){
    let report = Reports.findOne(reportId);
    if(report){
      let image = Images.findOne(report.imageId);
      if(image){
        return image.jpegBase64;
      }
    }
    return "";
  },
  year(){
    return (new Date()).getFullYear();
  },
  indexToRank(index){
    return index + 1;
  },
  pages(){
    let ids = FlowRouter.getParam('reportIds').split(",");
    return Reports.find({ _id: {$in: ids}}).count();
  }
});
