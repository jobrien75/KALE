/*

Filename: /imports/ui/layouts/reports/internal.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Layout internal report

Copyright (c) 2019 - Robert Bosch LLC

*/

import './internal.html';
import '../../components/compositionChart/compositionChart.js';
import '../../components/loader/loader.js';
let subscriptionState = new ReactiveVar();

import { Reports } from '../../../collections/reports.js';
import { Searches } from '../../../collections/searches.js';
import { Components } from '../../../collections/components.js';
import { Images } from '../../../collections/images.js';
import { nElements, attrFromName, sortObject, averageComposition, variationComposition, limitObject } from '../../../functions.js';
import { getElement } from '../../../elements.js';
import { getStatus, colorPalette } from '../../../colors.js';




Template.internalReport.onCreated(function(){
  this.autorun(()=>{
    if(!Meteor.userId()){
      FlowRouter.go("/");
    }
    let ids = FlowRouter.getParam('reportIds').split(",");
    subscriptionState.set("reports");
    Meteor.subscribe("reports.get",ids,()=>{
      Reports.find({ _id: {$in: ids}}).forEach((report)=>{
        if(report.results){

          let componentIds = [];
          report.results.forEach((match)=>{
            componentIds.push(match.component.id);
          });
          if(report.imageId){
            subscriptionState.set("images");
            Meteor.subscribe("images.get",report.imageId,()=>{
              subscriptionState.set("done");
            });
          }
          if(componentIds){
            subscriptionState.set("components");
            Meteor.subscribe('components.composition',componentIds,()=>{
              subscriptionState.set("done");
            });
          }
          if(report.searchId){
            subscriptionState.set("searches");
            Meteor.subscribe("searches.get",report.searchId,()=>{
              subscriptionState.set("done");
            });
          }

        }
      });
    });
  })
});

Template.internalReport.events({
  'click #print'(){
    alert("Make sure that you print in landscape mode");
    window.print();
  },
  'click #copy'(){
    const el = document.createElement('textarea');  // Create a <textarea> element
    el.value = window.location.href;                // Set its value to the URL that you want copied
    el.setAttribute('readonly', '');                // Make it readonly to be tamper-proof
    el.style.position = 'absolute';
    el.style.left = '-9999px';                      // Move outside the screen to make it invisible
    document.body.appendChild(el);                  // Append the <textarea> element to the HTML document
    const selected =
      document.getSelection().rangeCount > 0        // Check if there is any content selected previously
        ? document.getSelection().getRangeAt(0)     // Store selection if found
        : false;                                    // Mark as false to know no selection existed before
    el.select();                                    // Select the <textarea> content
    document.execCommand('copy');                   // Copy - only works as a result of a user action (e.g. click events)
    document.body.removeChild(el);                  // Remove the <textarea> element
    if (selected) {                                 // If a selection existed before copying
      document.getSelection().removeAllRanges();    // Unselect everything on the HTML document
      document.getSelection().addRange(selected);   // Restore the original selection
    }
  }
});

Template.internalReport.helpers({
  subscriptionState(){
    return subscriptionState.get();
  },
  get_reports(){
    let ids = FlowRouter.getParam('reportIds').split(",");
    return Reports.find({ _id: {$in: ids}},{sort:{"search.name": 1}});
  },
  reportIds(){
    return FlowRouter.getParam('reportIds');
  },
  searchId(){
    let ids = FlowRouter.getParam('reportIds').split(",");
    if(ids.length == 1){
      let report = Reports.findOne(ids[0]);
      if(report && report.searchId){
        return report.searchId;
      }
    }
    return false;
  },
  projectId(){
    let ids = FlowRouter.getParam('reportIds').split(",");
    if(ids.length > 1){
      let report = Reports.findOne(ids[0]);
      if(report){
        let search = Searches.findOne(report.searchId)
        if(search && search.project){
          return search.project;
        }
      }
    }
    return false;
  },
  result_spectra(reportId){
    let report = Reports.findOne(reportId);
    if(report){
      let result_spectra = [{
        searchId: report.searchId,
        spectrum: "AVERAGE"
      }];

      report.results.forEach((match)=>{
        result_spectra.push({
          componentId: match.component.id,
          spectrum: "AVERAGE"
        })
      })
      return result_spectra;
    }
    return [];
  },
  get_image_src(reportId){
    let report = Reports.findOne(reportId);
    if(report){
      let image = Images.findOne(report.imageId);
      if(image){
        return image.jpegBase64;
      }
    }
    return "";
  },
  get_TableHead(reportId){

    let report = Reports.findOne(reportId);
    if(!report) return;

    let search = Searches.findOne(report.searchId);
    if(!search) return;

    let elements = sortObject(averageComposition(search.composition));
    // elements = limitObject(elements, 8);
    return Object.keys(elements);

  },
  get_TableRows(reportId){

    let rows = [];
    let report = Reports.findOne(reportId);
    if(!report) return [];

    let search = Searches.findOne(report.searchId);
    if(!search) return [];

    let searchElements = sortObject(averageComposition(search.composition, 2));
    let variationElements = variationComposition(search.composition, 2);
    let elements = [];

    // If wanted to limit the number of elements: searchElements = limitObject(searchElements, 8);
    for(e in searchElements){
      elements.push({label: e, avg: searchElements[e], var: variationElements[e]});
    }

    rows.push({status:"original", match: false, title: report.search.project + ", " + search.name, elements})

    if(report.results){
      report.results = report.results.sort((a,b)=>{
        return b.match - a.match;
      })

      for(r in report.results){

        let component = Components.findOne(report.results[r].component.id);
        if(!component) continue;

        let componentElements = averageComposition(component.composition, 2);
        let variationElements = variationComposition(component.composition, 2);
        let elements = [];

        // avgElements = limitObject(avgElements, 8);
        for(e in searchElements){
          elements.push({label: e, avg: componentElements[e], var: variationElements[e]});
        }

        let status = getStatus(report.results[r].match);

        rows.push({status, match: report.results[r].match, title: report.results[r].component.product + ", " + report.results[r].component.name, measurementDate: component.measurementDate, elements})
      }
    }

    return rows;
  },
  year(){
    return (new Date()).getFullYear();
  },
  indexToRank(index){
    return index + 1;
  },
  pages(){
    let ids = FlowRouter.getParam('reportIds').split(",");
    return Reports.find({ _id: {$in: ids}}).count();
  }
});

let charts = {};

Template.internalReport.onRendered(function(){
  this.autorun(()=>{
    let ids = FlowRouter.getParam('reportIds').split(",");
    Reports.find({ _id: {$in: ids}}).forEach((report)=>{

        let ctx = $("#compositionChart"+report._id);

        if(report && ctx.length){
          let spectra = [{
            searchId: report.searchId,
          }];

          report.results = report.results.sort((a,b)=>{
            return b.originalMatch - a.originalMatch;
          })

          report.results.forEach((match)=>{
            spectra.push({
              componentId: match.component.id
            })
          })

          excluded_elements = report.search.excluded_elements;

          let labels = [];
          let datasets = [];
          let elements = {};


          let rank = 0;

          for(spectrum in spectra){

            if(spectra[spectrum].searchId){
              let search = Searches.findOne({_id: spectra[spectrum].searchId});

              if(!search) continue;

              let avg_elements = averageComposition(search.composition);
              for(element in avg_elements){
                if(typeof elements[element] == "undefined"){
                  elements[element] = [];
                }
                elements[element].push(avg_elements[element]);
              }
              labels.push("#"+rank++);
            }

            if(spectra[spectrum].componentId){
              let component = Components.findOne({_id: spectra[spectrum].componentId});

              if(!component) continue;

              let avg_elements = averageComposition(component.composition);
              for(element in avg_elements){
                if(typeof elements[element] == "undefined"){
                  elements[element] = [];
                }
                elements[element].push(avg_elements[element]);
              }
              labels.push("#"+rank++);
            }

          }

          let colors = colorPalette();
          let backgroundColors = colorPalette(0.8);

          for(element in elements){

            let borderColor = colors.shift();
            let backgroundColor = backgroundColors.shift();

            datasets.push({
                label: element,
                borderColor,
                backgroundColor,
                borderWidth: 1,
                data: elements[element],
                hidden: excluded_elements && excluded_elements.includes(element)
            });

          }

          if(datasets.length){

            if(charts[report._id]){
              charts[report._id].destroy(0);
            }

            charts[report._id] = new Chart(ctx, {
              type: 'bar',
              data: {
                labels,
                datasets
              },
              options: {
                animation: false,
                devicePixelRatio: 2,
                maintainAspectRatio: false,
                legend: {
                    display: true,
                    position: 'top',
                    labels: {
                      boxWidth: 6,
                      fontSize: 11,
                      padding: 7,
                      usePointStyle: false
                    }
                },
                tooltips: {
                  enabled: false
                },
                scales: {
                    xAxes: [{
                        stacked: true,
                        ticks: {
                          callback: function(value) {
                            return value.split(" ");
                          },
                          autoSkip: false,
                          maxRotation: 0,
                          minRotation: 0
                        }
                    }],
                    yAxes: [{
                        stacked: true,
                        scaleLabel: {
                          display: false,
                          labelString: "%"
                        }
                    }],

                },
              },
              plugins: [{
                beforeInit: function (chart) {
                  chart.data.labels.forEach(function (e, i, a) {
                    if (/\n/.test(e)) {
                      a[i] = e.split(/\n/)
                    }
                  })
                }
              }]
            });
          }

        }
    })

  })
});
