/*

Filename: /imports/ui/layouts/body/body.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Layout body

Copyright (c) 2019 - Robert Bosch LLC

*/

import './body.html';
import '../../components/nav/nav.js';
import '../../components/login/login.js';
import '../../components/loader/loader.js';

let subscriptionState = new ReactiveVar();

Template.App_body.onRendered(function(){
  Tracker.autorun(()=>{
    if(Meteor.userId()){

      subscriptionState.set("projects");
      Meteor.subscribe("projects",()=>{

        subscriptionState.set("searches");
        Meteor.subscribe("searches",()=>{

          subscriptionState.set("my searches");
          Meteor.subscribe("mySearches",()=>{

            subscriptionState.set("products");
            Meteor.subscribe("products",()=>{

              subscriptionState.set("components");
              Meteor.subscribe("components",()=>{

                subscriptionState.set("reports");
                Meteor.subscribe("reports",()=>{

                  subscriptionState.set("users");
                  Meteor.subscribe("users",()=>{

                    subscriptionState.set("done");
                  });
                });
              });
            });
          });
        });
      });
    }
  })
});

Template.App_body.events({

});

Template.App_body.helpers({
  userId(){
    return Meteor.userId();
  },
  subscriptionState(){
    return subscriptionState.get();
  },
  year(){
    return (new Date()).getFullYear();
  }
});
