/*

Filename: /imports/ui/components/compositionChart/compositionChart.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template compositionChart

Copyright (c) 2019 - Robert Bosch LLC

*/

import './compositionChart.html';
import {colorPalette} from '../../../colors.js';
import {nElements, split_minLength, attrFromName, averageComposition} from '../../../functions.js';

import { Searches } from '../../../collections/searches.js';
import { Components } from '../../../collections/components.js';

let compositionChart;
let excluded_elements = false;

Template.compositionChart.onRendered(function(){

  this.autorun(() => {

    let ctx = $("#compositionChart");
    let spectra = Template.currentData().spectra;
    if(Template.currentData().excluded_elements && Template.currentData().excluded_elements.get && Template.currentData().excluded_elements.get()){
      excluded_elements = Template.currentData().excluded_elements;
    }else{
      excluded_elements = false;
    }

    if(spectra && spectra.length && ctx.length){

      let pageOffset = pageYOffset;

      let labels = [];
      let datasets = [];
      let elements = {};

      for(spectrum in spectra){

        if(spectra[spectrum].searchId){
          let search = Searches.findOne({_id: spectra[spectrum].searchId});

          if(!search) continue;

          if(spectra[spectrum].spectrum == "AVERAGE"){

            let avg_elements = averageComposition(search.composition);
            for(element in avg_elements){
              if(typeof elements[element] == "undefined"){
                elements[element] = [];
              }
              elements[element].push(avg_elements[element]);
            }
            labels.push(search.name);

          }else{
            let search_elements = search.composition[attrFromName(spectra[spectrum].spectrum)].elements;

            for(element in search_elements){
              if(typeof elements[element] == "undefined"){
                elements[element] = [];
              }
              elements[element].push(search_elements[element]);
            }
            labels.push(spectra[spectrum].spectrum +", "+ search.name);
          }


        }


        if(spectra[spectrum].componentId){
          let component = Components.findOne({_id: spectra[spectrum].componentId});

          if(!component) continue;

          if(spectra[spectrum].spectrum == "AVERAGE"){

            let avg_elements = averageComposition(component.composition);
            for(element in avg_elements){
              if(typeof elements[element] == "undefined"){
                elements[element] = [];
              }
              elements[element].push(avg_elements[element]);
            }
            labels.push(component.name);

          }else{

            let component_elements = component.composition[attrFromName(spectra[spectrum].spectrum)].elements;
            for(element in component_elements){
              if(typeof elements[element] == "undefined"){
                elements[element] = [];
              }
              elements[element].push(component_elements[element]);
            }
            labels.push(spectra[spectrum].spectrum +", "+ component.name);

          }
        }

      }

      let colors = colorPalette();
      let backgroundColors = colorPalette(0.8);

      for(element in elements){

        let borderColor = colors.shift();
        let backgroundColor = backgroundColors.shift();

        datasets.push({
            label: element,
            borderColor,
            backgroundColor,
            borderWidth: 1,
            data: elements[element],
            hidden: excluded_elements && excluded_elements.get().includes(element)
        });

      }

      if(datasets.length){

        if(compositionChart){
          compositionChart.destroy(0);
        }

        compositionChart = new Chart(ctx, {
          type: 'bar',
          data: {
            labels,
            datasets
          },
          options: {
            animation: false,
            legend: {
                display: true,
                position: 'top',
                labels: {
                  boxWidth: 16,
                  fontColor: '#000',
                  fontFamily: "'Bosch Sans'",
                },
                onClick: function(e,legendItem){

                  if(excluded_elements){

                    // Change Reactive Var
                    let excluded = excluded_elements.get();

                    if(legendItem.hidden){ // if was hidden and is in Array -> remove from array
                      let tmp = [];
                      excluded.forEach((element)=>{
                        if(legendItem.text != element){
                          tmp.push(element);
                        }
                      })
                      excluded = tmp;
                    }else{
                      excluded.push(legendItem.text);
                    }

                    excluded_elements.set(excluded);
                  }else{

                    // Default when no Reactive Var
                    let index = legendItem.datasetIndex;
                    let ci = this.chart;
                    let meta = ci.getDatasetMeta(index);
                    meta.hidden = meta.hidden === null ? !ci.data.datasets[index].hidden : null;
                    ci.update();
                  }

                }
            },
            tooltips: {
              mode: 'index',
              intersect: false,
              position: 'nearest'
            },
            scales: {
                xAxes: [{
                    stacked: true,
                    ticks: {
                      callback: (label) => split_minLength(label, 3),
                      autoSkip: false,
                      maxRotation: 0,
                      minRotation: 0
                    },
                }],
                yAxes: [{
                    stacked: true,
                    ticks: {
                      padding: 5
                    }
                }],

            },
          },
          plugins: [{
            beforeInit: function (chart) {
              chart.data.labels.forEach(function (e, i, a) {
                if (/\n/.test(e)) {
                  a[i] = e.split(/\n/)
                }
              })
            }
          }]
        });
      }
      $(window).scrollTop(pageOffset);
    }

  })

});

Template.compositionChart.events({

});

Template.compositionChart.helpers({

});
