/*

Filename: /imports/ui/components/intensityChart/intensityChart.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template intensityChart

Copyright (c) 2019 - Robert Bosch LLC

*/

import './intensityChart.html';
import {colorPalette} from '../../../colors.js';
import {nElements, differential_equation} from '../../../functions.js';

let intensityChart;

Template.intensityChart.onRendered(function(){

  this.autorun(() => {

    let ctx = $("#intensityChart");
    let intensity = Template.currentData().intensity;

    if(intensity && typeof intensity == "object" && ctx.length){

    let datasets = [];
    let colors = colorPalette();
    let backgroundColors = colorPalette(0.02);
    for(key in intensity){
      if(intensity[key].data){

        /*
        Show differential_equation
        for(let ev = 0; intensity[key].data[ev+1]; ev++){
          intensity[key].data[ev].y = Math.sqrt(Math.abs(differential_equation(intensity[key].data[ev],intensity[key].data[ev+1])));
        }
        */

        datasets.push({
            label: intensity[key].title,
            pointRadius: 1,
            borderColor: colors.shift(),
            backgroundColor: backgroundColors.shift(),
            borderWidth: 1,
            data: nElements(intensity[key].data, 250),
            hidden: (datasets.length % 3)
        });
      }
    }

    if(datasets.length){
      if(intensityChart){
        intensityChart.destroy(0);
      }

      intensityChart = new Chart(ctx, {
          type: 'line',
          data: {
              datasets
          },
          options: {
            animation: false,
            devicePixelRatio: 2,
            maintainAspectRatio: false,
            elements: {
                line: {
                    // tension: 0 // disables bezier curves
                }
            },
            legend: {
                display: true,
                position: 'top',
                labels: {
                  boxWidth: 20
                }
            },
            tooltips: {
              enabled: true,
              mode: 'index',
              intersect: false
            },
            scales: {
              xAxes: [{
                  type: 'linear',
                  scaleLabel: {
                    display: true,
                    labelString: "keV"
                  },
                  position: 'bottom',
                  ticks: {
                      max: 20.5,
                      min: -0.5,
                      stepSize: 1,
                      maxRotation: 0,
                      minRotation: 0,
                      padding: 2
                  }
              }],
              yAxes: [{
                  type: 'linear',
                  scaleLabel: {
                    display: true,
                    labelString: "counts"
                  },
                  ticks: {
                    padding: 5
                  }
              }]
            },
          }
        });

    }
  }
  })
});

Template.intensityChart.events({

});

Template.intensityChart.helpers({

});
