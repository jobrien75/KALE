/*

Filename: /imports/ui/components/deleteButton/deleteButton.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template deleteButton

Copyright (c) 2019 - Robert Bosch LLC

*/

import './deleteButton.html';

Template.deleteButton.onRendered(()=>{

});

Template.deleteButton.events({
  'click #deleteButton_open'(){
    $('#deleteModal').fadeIn();
  },
  'click #deleteButton_submit'(){
    Meteor.call(this.collection+'.remove',this.id,(err,data)=>{
      if(data && data.error){
        alert(data.error);
      }
      $('#deleteModal').fadeOut();
      FlowRouter.go(this.collection);
    });
  },
  'click #deleteButton_close, click #deleteButton_abord'(){
    $('#deleteModal').fadeOut();
  }
});

Template.deleteButton.helpers({

});
