/*

Filename: /imports/ui/components/loader/loader.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template loader

Copyright (c) 2019 - Robert Bosch LLC

*/

import './loader.html';
