/*

Filename: /imports/ui/components/credentials/credentials.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template credentials

Copyright (c) 2019 - Robert Bosch LLC

*/

import './credentials.html';

Template.credentials.onRendered(()=>{

});

Template.credentials.events({

});

Template.credentials.helpers({
  changed(){
    let changed = Template.currentData().changed;
    if(changed){
      let user = Meteor.users.findOne(changed.from);
      let date = changed.at.toLocaleString();
      if(user){
        return user.name + " at " + date;
      }
    }
    return false;
  },
  created(){
    let created = Template.currentData().created;
    if(created){
      let user = Meteor.users.findOne(created.from);
      let date = created.at.toLocaleString();
      if(user){
        return user.name + " at " + date;
      }
    }
    return false;
  }
});
