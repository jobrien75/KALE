/*

Filename: /imports/ui/components/deleteSpectrum/deleteSpectrum.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template deleteSpectrum

Copyright (c) 2019 - Robert Bosch LLC

*/

import './deleteSpectrum.html';

Template.deleteSpectrum.onRendered(()=>{
});

Template.deleteSpectrum.events({
});

Template.deleteSpectrum.helpers({
});
