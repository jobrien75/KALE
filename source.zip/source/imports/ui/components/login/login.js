/*

Filename: /imports/ui/components/login/login.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template login

Copyright (c) 2019 - Robert Bosch LLC

*/

import './login.html';

Template.login.onRendered(()=>{

});

Template.login.events({
  'click #login-button'(){
    submitLogin();
  },
  'keyup'(event){
    if(event.key == "Enter"){
      submitLogin();
    }
  }
});

Template.login.helpers({

});

function submitLogin(){
  let username = $("#username").val();
  let password = $("#password").val();

  $("#loginIcon").addClass("refresh").removeClass("checkmark").addClass("spinning");

  if(!username){
    $("#errorMessage").html("Username is empty!").fadeIn();
  }else if(!password){
    $("#errorMessage").html("Password is empty!").fadeIn();
  }else{
    Meteor.loginWithPassword(username,password,(error)=>{
      $("#loginIcon").removeClass("refresh").removeClass("spinning").addClass("checkmark");
      if(error){
        $("input").addClass("invalid");
        $("#errorMessage").html("Username or Password wrong!").fadeIn();
      }
    });
  }
}
