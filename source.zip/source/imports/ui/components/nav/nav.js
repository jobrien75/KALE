/*

Filename: /imports/ui/components/nav/nav.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Blaze Template nav

Copyright (c) 2019 - Robert Bosch LLC

*/

import './nav.html';

import { permission } from '../../../permissions.js';

Template.nav.onRendered(function(){

});

Template.nav.events({
  'click .menuopen'(){
    $(".menuitemContainer").slideToggle("fast");
  },
  'click .menuitem'(){
    if(window.innerWidth < 768){
      $(".menuitemContainer").slideUp("fast");
    }
  },
  'click #logout'(){
    Meteor.logout();
  }
});

Template.nav.helpers({
  pages() {
    let pages = [
      {
        title: "Home",
        route: "/",
        active: FlowRouter.getRouteName() == "home" ? "active" : "",
      },
      {
        title: "Projects",
        route: "/projects",
        active: FlowRouter.getRouteName() == "projects" ? "active" : "",
      }
    ];

    if(permission("addProduct", "editProduct")){
      pages.push({
        title: "Products",
        route: "/products",
        active: FlowRouter.getRouteName() == "products" ? "active" : "",
      });
    }

    if(permission("addComponent", "editComponent")){
      pages.push({
        title: "Components",
        route: "/components",
        active: FlowRouter.getRouteName() == "components" ? "active" : "",
      });
    }

    return pages;
  }
});
