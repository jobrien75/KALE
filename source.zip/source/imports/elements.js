/*

Filename: /imports/ui/elements.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Defines the chemical elements

Copyright (c) 2019 - Robert Bosch LLC

*/

import {attrFromName} from './functions.js'

export function getElement(short){
  let elements = {
    h:  ["1", "H", "Wasserstoff", "Hydrogen"],
    he: ["2", "He", "Helium", "Helium"],
    li: ["3", "Li", "Lithium", "Lithium"],
    be: ["4", "Be", "Beryllium", "Beryllium"],
    b:  ["5", "B", "Bor", "Boron"],
    c:  ["6", "C", "Kohlenstoff", "Carbon"],
    n:  ["7", "N", "Stickstoff", "Nitrogen"],
    o:  ["8", "O", "Sauerstoff", "Oxygen"],
    f:  ["9", "F", "Fluor", "Fluorine"],
    ne: ["10", "Ne", "Neon", "Neon"],
    na: ["11", "Na", "Natrium", "Sodium"],
    mg: ["12", "Mg", "Magnesium", "Magnesium"],
    al: ["13", "Al", "Aluminium", "Aluminium"],
    si: ["14", "Si", "Silicium", "Silicon"],
    p:  ["15", "P", "Phosphor", "Phosphorus"],
    s:  ["16", "S", "Schwefel", "Sulfur"],
    cl: ["17", "Cl", "Chlor", "Chlorine"],
    ar: ["18", "Ar", "Argon", "Argon"],
    k:  ["19", "K", "Kalium", "Potassium"],
    ca: ["20", "Ca", "Calcium", "Calcium"],
    sc: ["21", "Sc", "Scandium", "Scandium"],
    ti: ["22", "Ti", "Titan", "Titanium"],
    v:  ["23", "V", "Vanadium", "Vanadium"],
    cr: ["24", "Cr", "Chrom", "Chromium"],
    mn: ["25", "Mn", "Mangan", "Manganese"],
    fe: ["26", "Fe", "Eisen", "Iron"],
    co: ["27", "Co", "Cobalt", "Cobalt"],
    ni: ["28", "Ni", "Nickel", "Nickel"],
    cu: ["29", "Cu", "Kupfer", "Copper"],
    zn: ["30", "Zn", "Zink", "Zinc"],
    ga: ["31", "Ga", "Gallium", "Gallium"],
    ge: ["32", "Ge", "Germanium", "Germanium"],
    as: ["33", "As", "Arsen", "Arsenic"],
    se: ["34", "Se", "Selen", "Selenium"],
    br: ["35", "Br", "Brom", "Bromine"],
    kr: ["36", "Kr", "Krypton", "Krypton"],
    rb: ["37", "Rb", "Rubidium", "Rubidium"],
    sr: ["38", "Sr", "Strontium", "Strontium"],
    y:  ["39", "Y", "Yttrium", "Yttrium"],
    zr: ["40", "Zr", "Zirconium", "Zirconium"],
    nb: ["41", "Nb", "Niob", "Niobium"],
    mo: ["42", "Mo", "Molybdän", "Molybdenum"],
    tc: ["43", "Tc", "Technetium", "Technetium"],
    ru: ["44", "Ru", "Ruthenium", "Ruthenium"],
    Rh: ["45", "Rh", "Rhodium", "Rhodium"],
    pd: ["46", "Pd", "Palladium", "Palladium"],
    ag: ["47", "Ag", "Silber", "Silver"],
    cd: ["48", "Cd", "Cadmium", "Cadmium"],
    in: ["49", "In", "Indium", "Indium"],
    sn: ["50", "Sn", "Zinn", "Tin"],
    sb: ["51", "Sb", "Antimon", "Antimony"],
    te: ["52", "Te", "Tellur", "Tellurium"],
    i:  ["53", "I", "Iod", "Iodine"],
    xe: ["54", "Xe", "Xenon", "Xenon"],
    cs: ["55", "Cs", "Cäsium", "Caesium"],
    ba: ["56", "Ba", "Barium", "Barium"],
    la: ["57", "La", "Lanthan", "Lanthanum"],
    ce: ["58", "Ce", "Cer", "Cerium"],
    pr: ["59", "Pr", "Praseodym", "Praseodymium"],
    nd: ["60", "Nd", "Neodym", "Neodymium"],
    pm: ["61", "Pm", "Promethium", "Promethium"],
    sm: ["62", "Sm", "Samarium", "Samarium"],
    eu: ["63", "Eu", "Europium", "Europium"],
    gd: ["64", "Gd", "Gadolinium", "Gadolinium"],
    tb: ["65", "Tb", "Terbium", "Terbium"],
    dy: ["66", "Dy", "Dysprosium", "Dysprosium"],
    ho: ["67", "Ho", "Holmium", "Holmium"],
    er: ["68", "Er", "Erbium", "Erbium"],
    tm: ["69", "Tm", "Thulium", "Thulium"],
    yb: ["70", "Yb", "Ytterbium", "Ytterbium"],
    lu: ["71", "Lu", "Lutetium", "Lutetium"],
    hf: ["72", "Hf", "Hafnium", "Hafnium"],
    ta: ["73", "Ta", "Tantal", "Tantalum"],
    w:  ["74", "W", "Wolfram", "Tungsten"],
    re: ["75", "Re", "Rhenium", "Rhenium"],
    os: ["76", "Os", "Osmium", "Osmium"],
    ir: ["77", "Ir", "Iridium", "Iridium"],
    pt: ["78", "Pt", "Platin", "Platinum"],
    au: ["79", "Au", "Gold", "Gold"],
    hg: ["80", "Hg", "Quecksilber", "Mercury"],
    tl: ["81", "Tl", "Thallium", "Thallium"],
    pb: ["82", "Pb", "Blei", "Lead"],
    bi: ["83", "Bi", "Bismut", "Bismuth"],
    po: ["84", "Po", "Polonium", "Polonium"],
    at: ["85", "At", "Astat", "Astatine"],
    rn: ["86", "Rn", "Radon", "Radon"],
    fr: ["87", "Fr", "Francium", "Francium"],
    ra: ["88", "Ra", "Radium", "Radium"],
    ac: ["89", "Ac", "Actinium", "Actinium"],
    th: ["90", "Th", "Thorium", "Thorium"],
    pa: ["91", "Pa", "Protactinium", "Protactinium"],
    u:  ["92", "U", "Uran", "Uranium"],
    np: ["93", "Np", "Neptunium", "Neptunium"],
    pu: ["94", "Pu", "Plutonium", "Plutonium"],
    am: ["95", "Am", "Americium", "Americium"],
    cm: ["96", "Cm", "Curium", "Curium"],
    bk: ["97", "Bk", "Berkelium", "Berkelium"],
    cf: ["98", "Cf", "Californium", "Californium"],
    es: ["99", "Es", "Einsteinium", "Einsteinium"],
    fm: ["100", "Fm", "Fermium", "Fermium"],
    md: ["101", "Md", "Mendelevium", "Mendelevium"],
    no: ["102", "No", "Nobelium", "Nobelium"],
    lr: ["103", "Lr", "Lawrencium", "Lawrencium"],
    rf: ["104", "Rf", "Rutherfordium", "Rutherfordium"],
    db: ["105", "Db", "Dubnium", "Dubnium"],
    sg: ["106", "Sg", "Seaborgium", "Seaborgium"],
    bh: ["107", "Bh", "Bohrium", "Bohrium"],
    hs: ["108", "Hs", "Hassium", "Hassium"],
    mt: ["109", "Mt", "Meitnerium", "Meitnerium"],
    uun:["110", "Uun", "Ununnilium", "Ununnilium"],
    uuu:["111", "Uuu", "Unununium", "Unununium"],
    uub:["112", "Uub", "Ununbium", "Ununbium"]
  };

  return elements[attrFromName(short)];
}

export function mainElement(composition){
  let max = 0;
  let mainElement;
  for(element in composition){
    if(composition[element] > max){
      max = composition[element];
      mainElement = element;
    }
  }
  return mainElement;
}

export function getMaterialClasses(elements){
  return [
    "unknown Material",
    "Carbon Alloy",
    "Tool Steel",
    "Ferritic Martensitic",
    "Austenitic",
    "Copper",
    "Bronze",
    "Brass",
    "Aluminum",
  ].sort();
}

export function materialClass(elements){
  let tollerance = 0.9; // -10%
  let mainEle = mainElement(elements);

  let materialClass = "unknown Material";

  if(mainEle == "Fe"){

    // Carbon Alloy: Default Iron Class
    materialClass = "Carbon Alloy";

    // Tool Steel:  1 or more elements with 1.0% and higher elemental concentration.  [This is a difficult class to define as some tool steels only have 1 or 2 elements at 1%.]
    // More common grades have elevated Cr, Mo, W, V, and Co and it is these higher concentrations that define the higher alloyed tool steels.
    let counter = 0;
    for(e in elements){
      if(elements[e] > 1 * tollerance) counter++;
    }
    if(counter >= 3){ // 2 + Fe
      materialClass = "Tool Steel";
    }

    if(elements.Cr > 10 * tollerance){
      // Ferritic Martensitic:  10% Cr and higher
      materialClass = "Ferritic Martensitic";

      // Austenitic:  10% Cr and higher AND 8% Ni and higher
      if(elements.Ni > 8 * tollerance){
        materialClass = "Austenitic";
      }
    }

  }

  if(mainEle == "Cu"){
    materialClass = "Copper";
  }

  // Brass:  Most have 50% minimum Cu, with remainder Zn.  One type has down to 30% Cu, with remainder is Zn.
  if(mainEle == "Cu" && elements.Zn > 30 * tollerance){
    materialClass = "Brass";
  }

  // Bronze:  Mostly Cu-based.  12% Sn minimum, with additional alloy elements of Al, Mn, Ni, and Zn
  if(mainEle == "Cu" && elements.Sn > 12 * tollerance){
    materialClass = "Bronze";
  }

  // Aluminum:  primarily Al, with alloy of Mg, Si, Fe, and Mn.
  if(mainEle == "Al"){
    materialClass = "Aluminum";
  }

  return materialClass;
}
