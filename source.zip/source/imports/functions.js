/*

Filename: /imports/ui/functions.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements universial functions

Copyright (c) 2019 - Robert Bosch LLC

*/



export function ucFirst(string) {
    return string.substring(0, 1).toUpperCase() + string.substring(1);
}

export function nextLetter(letter){
    return letter.replace(/([A-Z])[^A-Z]*$/, function(a){
        var c = a.charCodeAt(0);
        switch(c){
            case 90: return 'A';
            case 122: return 'a';
            default: return String.fromCharCode(++c);
        }
    });
}

export function contains(haystack,needle){
  return haystack.replace(needle) != haystack;
}

export function attrFromName(name){
  if(!name){
    return "undefined";
  }
  return name.trim().split(" ").join("_").replace(/\W/gm,'').toLowerCase();
}

export function nElements(array, nElements){
  let data = [];
  let delta = Math.floor( array.length / nElements );
  for (i = 0; i < array.length; i += delta) {
    data.push(array[i]);
  }
  return data;
}

export function split_minLength(value, minLength) {
  let split_value = value.split("");
  let split_label = [];
  let s = 0;
  while(split_value.length > 0){
    if(!split_label[s]) split_label[s] = [];
    let char = split_value.pop();
    if(char == " " && split_label[s].length > minLength && split_value.length > minLength){
      s++;
    }else{
      split_label[s] = char + split_label[s];
    }
  }
  return split_label.reverse();
}

export function adjustComposition(com1, com2 = false, excluded = []){
  let difference = 0, sum = 0;
  let result = {};

  for(element in com1){
    if(!(element in com2) || excluded.includes(element)){
      difference += com1[element];
    }else{
      result[element] = com1[element];
    }
    sum += com1[element];
  }

  if(difference > 0 && sum > 0){
    for(element in result){
      result[element] += result[element] * difference / sum;
    }
  }

  return result;
}

export function averageComposition(spectra, fixed = 2){

  let avg_elements = {};
  let sum_elements = {};
  let counter = 1;

  for(s in spectra){
    for(e in spectra[s].elements){
      if(typeof sum_elements[e] == "undefined"){
        sum_elements[e] = 0;
      }
      sum_elements[e] += spectra[s].elements[e];
      avg_elements[e] = (sum_elements[e] / counter).toFixed(fixed);
    }
    counter++;
  }

  return avg_elements;
}

export function medianComposition(spectra){

  let all_elements = {};

  for(s in spectra){
    for(e in spectra[s].elements){
      if(typeof all_elements[e] == "undefined"){
        all_elements[e] = [];
      }
      all_elements[e].push(spectra[s].elements[e]);
    }
  }

  for(e in all_elements){
    all_elements[e] = median(all_elements[e]);
  }
  return all_elements;
}

function median(arr){
    arr = arr.sort();
    let median = Math.floor(arr.length / 2);
    return arr[median];
}

export function stdDeviationComposition(spectra, fixed = 2){

  let avg_elements = averageComposition(spectra, fixed);
  let ssum_elements = {};
  let sdev_elements = {};
  let counter = 1;

  for(s in spectra){
    for(e in spectra[s].elements){
      if(typeof ssum_elements[e] == "undefined"){
        ssum_elements[e] = 0;
      }
      ssum_elements[e] += (spectra[s].elements[e] - avg_elements[e]) * (spectra[s].elements[e] - avg_elements[e]);
    }
    counter++;
  }

  for(e in ssum_elements){
    sdev_elements[e] = Math.sqrt(ssum_elements[e] / counter).toFixed(fixed);
  }

  return sdev_elements;
}

export function variationComposition(spectra, fixed = 2){

  let var_elements = {};
  let min_elements = {};
  let max_elements = {};

  for(s in spectra){
    for(e in spectra[s].elements){
      if(typeof min_elements[e] == "undefined" || min_elements[e] > spectra[s].elements[e]){
        min_elements[e] = spectra[s].elements[e];
      }
      if(typeof max_elements[e] == "undefined" || max_elements[e] < spectra[s].elements[e]){
        max_elements[e] = spectra[s].elements[e];
      }
      var_elements[e] = ((max_elements[e] - min_elements[e]) / 2).toFixed(fixed);
    }
  }

  return var_elements;
}

export function minComposition(spectra){

  let min_elements = {};

  for(s in spectra){
    for(e in spectra[s].elements){
      if(typeof min_elements[e] == "undefined" || min_elements[e] > spectra[s].elements[e]){
        min_elements[e] = spectra[s].elements[e];
      }
    }
  }

  return min_elements;
}

export function maxComposition(spectra){

  let max_elements = {};

  for(s in spectra){
    for(e in spectra[s].elements){
      if(typeof max_elements[e] == "undefined" || max_elements[e] < spectra[s].elements[e]){
        max_elements[e] = spectra[s].elements[e];
      }
    }
  }

  return max_elements;
}

export function sortObject(obj){

  let sortable = [];
  for (let k in obj) {
      sortable.push([k, obj[k]]);
  }
  sortable.sort(function(a, b) {
      return b[1] - a[1];
  });

  let sortedObj = {};
  sortable.forEach((ele)=>{
    sortedObj[ele[0]] = ele[1];
  })

  return sortedObj;
}

export function limitObject(object, limit){
  let limitObject = {};

  for(k in object){
    if(limit-- > 0){
      limitObject[k] = object[k];
    }
  }

  return limitObject;
}

export function differential_equation(point1,point2){
  if(point1.x && point1.y && point2.x && point2.y){
    return (point2.y - point1.y) / (point2.x - point1.x);
  }
  return 0;
}

export function averageIntensity(spectra){
  let intensity_average = [];
  counter = 0;

  for(search_spectrum in spectra){
    for(ev in spectra[search_spectrum].data){
      if(!intensity_average[ev]){
        intensity_average[ev] = {
          x: 0,
          y: 0
        };
      }
      intensity_average[ev].x = spectra[search_spectrum].data[ev].x;
      intensity_average[ev].y += spectra[search_spectrum].data[ev].y;
    }
    counter++;
  }

  for(ev in intensity_average){
    intensity_average[ev].y /= counter;
  }

  return intensity_average;
}

export function range2set(begin, end, incrementSize){
  let set = [];
  let fixed = Math.abs(Math.floor(Math.log10(incrementSize))); // e.g. transforms 0.01 to 2
  let increment = begin;
  while(increment <= end){
    set.push(increment.toFixed(fixed));
    increment = Number(increment) + incrementSize;
  }
  return set;
}

export function objectAverage(obj){
  let values = Object.values(obj);
  let length = values.length
  return values.reduce((a,b)=>(a+b)/length);
}
