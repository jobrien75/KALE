/*

Filename: /imports/ui/matchCalculation.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements the match calculation

Copyright (c) 2019 - Robert Bosch LLC

*/

import {adjustComposition, sortObject, differential_equation} from './functions.js';
import { Searches } from './collections/searches.js';
import { Components } from './collections/components.js';

import { match_CoefficientOfDetermination } from './matchCalculation/coefficientOfDetermination.js';
import { match_AveragedComposition } from './matchCalculation/averagedComposition.js';
import { match_Intensity } from './matchCalculation/intensity.js';
import { match_JaccardCoefficient } from './matchCalculation/jaccardCoefficient.js';


/*
Calculates the matches


@param searchId the id of current search

return:
  [
      {
         "component":{
            "id":<componentId>,
            "name":<componentName>,
            "product":<productId>,
            "comment":<componentComment>,
            "spectrum":<bestMatchingSpectrumTitle>,
         },
         "search":{
            "id":<searchId>,
            "name":<searchName>,
            "spectrum":<bestMatchingSpectrumTitle>
         },
         "match":<match in percent>
      },
      ...
   ]
*/

export function calculateMatches(searchId, algorithm, excluded_elements = [], nResults = 10,  minMatch = 0.5, product = "all", materialClass = "all"){

  let search = Searches.findOne(searchId);
  if(!search){
    return;
  }

  let filter = {};
  if(materialClass && materialClass != "all"){
    filter = {...filter, materialClass};
  }
  if(product && product != "all"){
    filter = {...filter, product};
  }


  let components = Components.find(filter);

  switch (algorithm) {
    case "CoefficientOfDetermination":
      var results = match_CoefficientOfDetermination(search,components,excluded_elements);
      break;
    case "AveragedComposition":
      var results = match_AveragedComposition(search,components,excluded_elements);
      break;
    case "Intensity":
      var results = match_Intensity(search,components);
      break;
    case "Jaccard":
      var results = match_JaccardCoefficient(search,components,excluded_elements);
      break;
    default:
      var results = match_CoefficientOfDetermination(search,components,excluded_elements);
  }


  return results.filter(result => result.match >= minMatch)
                .sort((a,b) =>  b.match - a.match)
                .slice(0, nResults);
}

export function matchAlgorithms(){
  return [
    {
      key: "CoefficientOfDetermination",
      label: "Coefficient of Determination"
    },
    {
      key: "AveragedComposition",
      label: "Averaged Composition CoD"
    },
    {
      key: "Intensity",
      label: "Intensity"
    },
    /* Jaccard Coefficient is not working yet
    {
      key: "Jaccard",
      label: "Modified Jaccard"
    },
    */
  ]
}
