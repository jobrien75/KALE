/*

Filename: /imports/collections/reports.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Represents the MongoDB Collection reports

Copyright (c) 2019 - Robert Bosch LLC

*/

import { Mongo } from 'meteor/mongo';
export const Reports = new Mongo.Collection('reports');
