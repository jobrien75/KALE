/*

Filename: /imports/collections/products.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Represents the MongoDB Collection products

Copyright (c) 2019 - Robert Bosch LLC

*/

import { Mongo } from 'meteor/mongo';
export const Products = new Mongo.Collection('products');
