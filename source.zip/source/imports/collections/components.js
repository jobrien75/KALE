/*

Filename: /imports/collections/components.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Represents the MongoDB Collection components

Copyright (c) 2019 - Robert Bosch LLC

*/

import { Mongo } from 'meteor/mongo';
export const Components = new Mongo.Collection('components');
