/*

Filename: /imports/collections/searches.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Represents the MongoDB Collection searches

Copyright (c) 2019 - Robert Bosch LLC

*/

import { Mongo } from 'meteor/mongo';
export const Searches = new Mongo.Collection('searches');
