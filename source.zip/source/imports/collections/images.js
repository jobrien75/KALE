/*

Filename: /imports/collections/images.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Represents the MongoDB Collection images

Copyright (c) 2019 - Robert Bosch LLC

*/

import { Mongo } from 'meteor/mongo';
export const Images = new Mongo.Collection('images');
