/*

Filename: /imports/collections/projects.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Represents the MongoDB Collection projects

Copyright (c) 2019 - Robert Bosch LLC

*/

import { Mongo } from 'meteor/mongo';
export const Projects = new Mongo.Collection('projects');
