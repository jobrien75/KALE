/*

Filename: /imports/ui/parsers.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements the import parsers

Copyright (c) 2019 - Robert Bosch LLC

*/

import {nextLetter, attrFromName, contains} from './functions.js';

// parser for EDX files in XLSX format
// is used for uploading composition in editSearch and editComponent
export function parseCompositionXLSX(edx){

  // check if file have required fields
  if(!(edx && edx.Sheets && edx.Sheets.Sheet1
      && edx.Sheets.Sheet1.B71 && edx.Sheets.Sheet1.B71.v == "Statistics"
      && edx.Sheets.Sheet1.B72 && edx.Sheets.Sheet1.B72.v == "Max"
      && edx.Sheets.Sheet1.B73 && edx.Sheets.Sheet1.B73.v == "Min"
      && edx.Sheets.Sheet1.B74 && edx.Sheets.Sheet1.B74.v == "Average"
      && edx.Sheets.Sheet1.B75 && edx.Sheets.Sheet1.B75.v == "Standard Deviation"
      && edx.Sheets.Sheet1.B82 && edx.Sheets.Sheet1.B82.v == "Spectrum Label")){
    console.error("Statistics, Max, Min, Average, Standard Deviation, Spectrum Label in column B not found!");
  	return false;
  }

  let b = 83;
  let spectras = [];

  // loop the column B down, till the word "Total";
  do{
    if(b > 200 || !edx.Sheets.Sheet1["B"+b]){
      console.error("Total in column B not found!");
      return false;
    }

    for(let c = "C"; edx.Sheets.Sheet1[c+b]; c = nextLetter(c)){
      if(!spectras[c.charCodeAt(0)]){
        spectras[c.charCodeAt(0)] = {
          title: edx.Sheets.Sheet1[c+82].v,
          elements: {}
        };
      }
      spectras[c.charCodeAt(0)].elements[edx.Sheets.Sheet1["B"+b].v] = edx.Sheets.Sheet1[c+b].v
    }

    b++;
  } while(edx.Sheets.Sheet1["B"+b] && edx.Sheets.Sheet1["B"+b].v != "Total");


  // check if sum of all elements is 100 %
  for(n in spectras){
    let sum = 0;
    for(s in spectras[n]){
      sum += spectras[n][s];
    }

    let difference = Math.abs(sum - 100);
    let warnText = "Sum of " + edx.Sheets.Sheet1[String.fromCharCode(n)+82].v + " is not 100\nSum is " + sum;

    if(difference > 0.05){
      console.error(warnText);
      return false;
    }else if(difference > 0.001){
      console.warn(warnText);
    }
  }

  return spectras;
}

// parser for EDX raw data files in TXT format
// is used for uploading Intensity in editSearch and editComponent
export function parseIntensityTXT(data){
  let spectrum = {
    labels: [],
    data: []
  };
  let listen_spectrum = false;
  let lines = data.split("\n");
  for(l in lines){
    let val =  lines[l].split(":").map(e => e.trim());

    if(val[0] == '#FORMAT' && val[1] != 'EMSA/MAS Spectral Data File'){
      console.error('No EMSA/MAS Spectral Data File');
      return false;
    }

    if(val[0] == '#VERSION' && val[1] != '1.0'){
      console.warning('Maybe unsupported Version, supported is 1.0');
      return false;
    }

    if(val[0] == "#SPECTRUM"){
      listen_spectrum = true;
      continue;
    }

    if(listen_spectrum){
      val = val[0].split(",").map(e => e.trim());

      spectrum.data.push({
        x: Number(val[0]),
        y: Number(val[1])
      });

    }else if(val[0] == "##OXINSTLABEL"){
      let label = val[1].split(",")
      spectrum.labels.push({
        x: Number(label[1]),
        el: label[2]
      });
    }else if(contains(val[1],",")){
      spectrum[attrFromName(val[0])] = val[1].split(",");
    }else if(val[0] == "#DATE"){
      spectrum[attrFromName(val[0])] = new Date(val[1].split("-").join(" "));
    }else if(val[0] == "#TIME"){
      spectrum[attrFromName("#DATE")] = new Date(new Date(new Date(spectrum[attrFromName("#DATE")]).setHours(val[1])).setMinutes(val[2]));
    }else if(["#TITLE","#XUNITS","#YUNITS","##OXINSTSTROB","##OXINSTPT","#BEAMKV","#REALTIME","#LIVETIME","#SIGNALTYPE"].includes(val[0])){
      spectrum[attrFromName(val[0])] = val[1];
    }
  }
  return spectrum;
}

// parser for tiff Images to convert it to jpeg
// is used for uploading Images in editSearch
export function compressTiffToJPEG(data, factor){
  let tiff = new Tiff({buffer: data});
  let canvas = tiff.toCanvas();
  return canvas.toDataURL('image/jpeg', factor);
}
