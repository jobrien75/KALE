/*

Filename: /imports/ui/permissions.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Defines the permissions

Copyright (c) 2019 - Robert Bosch LLC

*/




// Function that checks if the current User has a spesific permissions
// variable arguments is holding all given arguments
export function permission(/* permissions in arguments */){
  let user = Meteor.user();

  if(user && user.permission){
    let permitted = false;
    Array.from(arguments).forEach((key)=>{
      permitted = permitted || user.permission.includes(key);
    })
    return permitted;
  }

  return false;
}

// defines all availible permissions
export function get_permissions(){
  return [
    {
      key: "addSearch",
      label: "Add Search"
    },
    {
      key: "editSearch",
      label: "Edit Search"
    },
    {
      key: "removeSearch",
      label: "Delete Search"
    },
    {
      key: "createReport",
      label: "Create Report"
    },
    {
      divider: true
    },{
      key: "addProject",
      label: "Add Project"
    },
    {
      key: "editProject",
      label: "Edit Project"
    },
    {
      key: "removeProject",
      label: "Delete Project"
    },
    {
      divider: true
    },{
      key: "addProduct",
      label: "Add Product"
    },
    {
      key: "editProduct",
      label: "Edit Product"
    },
    {
      key: "removeProduct",
      label: "Delete Product"
    },
    {
      divider: true
    },
    {
      key: "addComponent",
      label: "Add Component"
    },
    {
      key: "editComponent",
      label: "Edit Component"
    },
    {
      key: "removeComponent",
      label: "Delete Component"
    },
    {
      divider: true
    },
    {
      key: "editUser",
      label: "Edit User"
    },
    {
      key: "editUserPermissons",
      label: "Edit Permissions"
    },
    {
      key: "resetPassword",
      label: "Reset Password"
    },
    /* deleting Users will causes problems!
    {
      key: "removeUser",
      label: "Delete User"
    }
    */
  ];
}
