/*

Filename: /imports/ui/colors.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Defines the Bosch colors

Copyright (c) 2019 - Robert Bosch LLC

*/

export function colorPalette(opacity = 1){
  return [

    // Base Colors
    'rgba( 234,   0,  22, '+opacity+')',
    'rgba( 185,   2, 118, '+opacity+')',
    'rgba(  80,  35, 127, '+opacity+')',
    'rgba(   0,  86, 145, '+opacity+')',
    'rgba(   0, 142, 207, '+opacity+')',
    'rgba(   0, 168, 176, '+opacity+')',
    'rgba( 120, 190,  32, '+opacity+')',
    'rgba(   0,  98,  73, '+opacity+')',
    'rgba( 252, 175,  23, '+opacity+')',

    // B50 Colors
    'rgba( 117,   0,  11, '+opacity+')',
    'rgba(  93,   1,  59, '+opacity+')',
    'rgba(  40,  18,  64, '+opacity+')',
    'rgba(   0,  43,  73, '+opacity+')',
    'rgba(   0,  71, 104, '+opacity+')',
    'rgba(   0,  84,  88, '+opacity+')',
    'rgba(  60,  95,  16, '+opacity+')',
    'rgba(   0,  49,  37, '+opacity+')',
    'rgba( 126,  88,  12, '+opacity+')',

    // W50 Colors
    'rgba( 244, 128, 139, '+opacity+')',
    'rgba( 220, 128, 186, '+opacity+')',
    'rgba( 167, 145, 191, '+opacity+')',
    'rgba( 127, 170, 200, '+opacity+')',
    'rgba( 127, 198, 231, '+opacity+')',
    'rgba( 127, 211, 215, '+opacity+')',
    'rgba( 187, 222, 143, '+opacity+')',
    'rgba( 127, 176, 164, '+opacity+')',
    'rgba( 253, 215, 139, '+opacity+')',
  ];
}

export function getStatus(match,strings = ["ok","warning","error"]){
  if(match > 0.90){
    return strings[0]
  }else if(match > 0.80){
    return strings[1]
  }else{
    return strings[2]
  }
}

Chart.defaults.global.defaultFontColor = '#000';
Chart.defaults.global.defaultFontFamily = "'Bosch Sans'";
