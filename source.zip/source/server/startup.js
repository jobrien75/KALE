/*

Filename: /server/startup.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Defines Scripts, that runs on server startup

Copyright (c) 2019 - Robert Bosch LLC

*/

import { Meteor } from 'meteor/meteor';

import { get_permissions } from '../imports/permissions.js';

Meteor.startup(() => {
  console.log("Startup");
  if(!Meteor.users.findOne({username: "admin"})){
    console.log("create Admin");
    let password = Math.random().toString(36).substr(2);
    Accounts.createUser({
      username: "admin",
      password: password,
    });
    console.log("Password: "+password);
  }
  let permission = [];

  get_permissions().forEach((perm)=>{
    if(perm.key)
      permission.push(perm.key);
  });

  Meteor.users.update({username: "admin"},{
    $set:{
      permission
    }
  });
  console.log("Meteor is running");
});
