/*

Filename: /server/methods/components.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements all methods and publishes for the collection components

Copyright (c) 2019 - Robert Bosch LLC

*/


// All links-related publications
import { Meteor } from 'meteor/meteor';
import { check } from 'meteor/check';

import { Products } from '../../imports/collections/products.js';
import { Components } from '../../imports/collections/components.js';
import { attrFromName } from '../../imports/functions.js';
import { mainElement, materialClass, getMaterialClasses } from '../../imports/elements.js';
import { permission } from '../../imports/permissions.js';

Meteor.publish('components', ()=>{
  if(Meteor.userId()){
    return Components.find({},{
      fields:{
        name: 1,
        product: 1,
        materialClass: 1,
        plating: 1,
        comment: 1
      }
    });
  }
});

Meteor.publish('components.composition', (componentIds)=>{
  if(Meteor.userId()){
    return Components.find({_id: {$in:componentIds}},{
      fields:{
        name: 1,
        composition: 1,
        measurementDate: 1
      }
    });
  }
});

Meteor.publish('components.get', (componentIds)=>{
  check(componentIds, String);

  if(Meteor.userId()){
    return Components.find({ _id: componentIds });
  }
});

Meteor.methods({
  'components.add'(name,productId){
    if(permission("addComponent")){
      check(name, String);
      check(productId, String);

      let product = Products.findOne(productId);

      if(product){
        // return the created ComponentId
        return Components.insert({
          name,
          product: product._id,
          created:{
            from: Meteor.userId(),
            at: new Date()
          }
        });
      }else{
        return {error: "Product not found"}
      }
    }
  },
  'components.setName'(componentId,name){
    if(permission("editComponent")){
      check(componentId, String);
      check(name, String);

      return Components.update(componentId,{ $set: {
        name,
        changed: {
          from: Meteor.userId(),
          at: new Date()
        }
      } });
    }
  },
  'components.setProduct'(componentId,productId){
    if(permission("editComponent")){
      check(componentId, String);
      check(productId, String);

      let product = Products.findOne(productId);

      if(product){
        return Components.update(componentId,{ $set: {
          product: product._id,
          changed: {
            from: Meteor.userId(),
            at: new Date()
          }
        } });
      }
    }
  },
  'components.setAnalyst'(componentId,analystId){
    if(permission("editComponent")){
      check(componentId, String);
      check(analystId, String);

      let analyst = Meteor.users.findOne(analystId);

      if(analyst){
        return Components.update(componentId,{ $set: {
          analyst: analyst._id,
          changed: {
            from: Meteor.userId(),
            at: new Date()
          }
        } });
      }
    }
  },
  'components.setPlating'(componentId,plating){
    if(permission("editComponent")){
      check(componentId, String);
      check(plating, String);


      return Components.update(componentId,{ $set: {
        plating,
        changed: {
          from: Meteor.userId(),
          at: new Date()
        }
      } });
    }
  },
  'components.setMeasurementDate'(componentId,measurementDate){
    if(permission("editComponent")){
      check(componentId, String);
      check(measurementDate, Date);


      return Components.update(componentId,{ $set: {
        measurementDate,
        changed: {
          from: Meteor.userId(),
          at: new Date()
        }
      } });
    }
  },
  'components.setComment'(componentId,comment){
    if(permission("editComponent")){
      check(componentId, String);
      check(comment, String);

      return Components.update(componentId,{ $set: {
        comment,
        changed: {
          from: Meteor.userId(),
          at: new Date()
        }
      }});
    }
  },
  'components.setMaterialClass'(componentId,materialClass){
    if(permission("editComponent")){
      check(componentId, String);
      check(materialClass, String);

      let materialClasses = getMaterialClasses();

      if(!materialClasses.includes(materialClass)){
        return "invalid materialClass";
      }

      return Components.update(componentId,{ $set: {
        materialClass,
        changed: {
          from: Meteor.userId(),
          at: new Date()
        }
      }});
    }
  },
  'components.addComposition'(componentId,spectrumTitle,elements){
    if(permission("editComponent")){
      check(componentId, String);
      check(spectrumTitle, String);
      check(elements, Object);

      let component = Components.findOne(componentId);

      if(component){
        if(!component.composition){
          component.composition = {};
        }

        if(!component.composition[attrFromName(spectrumTitle)]){
          component.composition[attrFromName(spectrumTitle)] = {
            title: spectrumTitle,
            elements
          };
        }else{
          component.composition[attrFromName(spectrumTitle)].elements = elements;
        }

        let composition = {};
        Object.keys(component.composition).sort().forEach(function(key) {
          composition[key] = component.composition[key];
        });

        return Components.update(componentId,{ $set: {
          composition: component.composition,
          mainElement: mainElement(elements),
          materialClass: materialClass(elements),
          analyst: Meteor.userId(),
          measurementDate: new Date(),
          changed: {
            from: Meteor.userId(),
            at: new Date()
          }
        } });
      }
    }
  },
  'components.removeSpectrum'(componentId,spectrumTitle){
    if(permission("removeComponent")){
      check(componentId, String);
      check(spectrumTitle, String);

      let component = Components.findOne(componentId);

      if(component && component.composition){

        let newComposition = {};
        for(spectrum in component.composition){
          if(spectrum != attrFromName(spectrumTitle)){
            newComposition[spectrum] = component.composition[spectrum];
          }
        }
        component.composition = newComposition;


        if(component.intensity){
          let newIntensity = {};
          for(spectrum in component.intensity){
            if(spectrum != attrFromName(spectrumTitle)){
              newIntensity[spectrum] = component.intensity[spectrum];
            }
          }
          component.intensity = newIntensity;
        }

        component.changed = {
          from: Meteor.userId(),
          at: new Date()
        }

        return Components.update(componentId,component);
      }
    }
  },
  'components.addIntensity'(componentId,spectrumTitle,intensity){
    if(permission("editComponent")){
      check(componentId, String);
      check(spectrumTitle, String);
      check(intensity, Object);

      let component = Components.findOne(componentId);

      if(component){

        if(!component.composition || !component.composition[attrFromName(spectrumTitle)]){
          return {error: spectrumTitle + " not found within "+component.name+", upload matching Composition-File first."};
        }else{
          if(!component.intensity){
            component.intensity = {};
          }

          component.instrument = intensity.signaltype;
          delete intensity.signaltype;
          component.measurementDate = intensity.date;
          delete intensity.date;

          component.analyst = Meteor.userId();
          component.intensity[attrFromName(spectrumTitle)] = intensity;

          let sortedIntensity = {};
          Object.keys(component.composition).forEach(function(key) {
            sortedIntensity[key] = component.intensity[key];
          });
          component.intensity = sortedIntensity;
        }

        component.changed = {
          from: Meteor.userId(),
          at: new Date()
        };

        return Components.update(componentId,component);
      }
    }
  },
  'components.remove'(componentId){
    if(permission("removeComponent")){
      check(componentId, String);
      return Components.remove(componentId);
    }
  }
});
