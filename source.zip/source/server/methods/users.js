/*

Filename: /server/methods/users.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements all methods and publishes for the collection users

Copyright (c) 2019 - Robert Bosch LLC

*/

// All links-related publications
import { Meteor } from 'meteor/meteor';
import { check, Match } from 'meteor/check';

import { permission } from '../../imports/permissions.js';


Meteor.publish('self', ()=>{
  return Meteor.users.find(Meteor.userId(),{
    fields: {
      permission: 1,
      department: 1
    }
  });
});

Meteor.publish('users', ()=>{
  return Meteor.users.find({username: {$ne: "admin"}},{
    fields: {
      name: 1,
      username: 1,
      permission: 1,
      department: 1,
      active: 1
    }
  });
});

function checkUsername(username,callback){
  username = username.trim();
  username = username.split(" ").join("_");
  if(!username){
    return "username_empty";
  }
  if(Meteor.users.findOne({username: username})){
    return "username_exists";
  }
  return callback(username);
}

Meteor.methods({
  'users.add'(name,department){
    if(permission("editUser")){
      check(name, String);
      check(department, Match.Maybe(String));

      let password = Math.random().toString(36).substr(2);

      let userId = checkUsername(name,(checkedUsername)=>{
        return Accounts.createUser({
          username: checkedUsername,
          password
        });
      });

      if(userId){
        Meteor.users.update(userId,{ $set: {
          name,
          department
        } });
      }

      return userId;
    }
  },
  'users.setName'(userId,name){
    if(permission("editUser") || userId == Meteor.userId()){
      check(name, String);
      check(userId, String);
      return Meteor.users.update(userId,{ $set: {
        name
      } });
    }
  },
  'users.setUsername'(userId,username){
    if(permission("editUser") || userId == Meteor.userId()){
      check(username, String);
      check(userId, String);
      return checkUsername(username,(checkedUsername)=>{
        return Meteor.users.update(userId,{ $set: {
          username: checkedUsername
        } });
      });
    }
  },
  'users.setDepartment'(userId,department){
    if(permission("editUser") || userId == Meteor.userId()){
      check(department, String);
      check(userId, String);
      return Meteor.users.update(userId,{ $set: {
        department
      } });
    }
  },
  'users.setActive'(userId,active){
    if(permission("editUser")){
      check(active, Boolean);
      check(userId, String);
      return Meteor.users.update(userId,{ $set: {
        active
      } });
    }
  },
  'users.setPermission'(userId,permissions){
    check(permissions, Array);
    check(userId, String);

    if(userId == Meteor.userId()){
      return "self_editing_not_allowed";
    }

    permissions.forEach((perm)=>{
      if(!permission(perm)){
        return "not_enought_permissions";
      }
    });

    if(permissions.length == 0){
      return Meteor.users.update(userId,{ $unset: {
        permission: 1
      } });
    }else{
      return Meteor.users.update(userId,{ $set: {
        permission:permissions
      } });
    }
  },
  'users.resetPassword'(userId){
    check(userId, String);
    if(permission("resetPassword")){
      let password = Math.random().toString(36).substr(2);
      Accounts.setPassword(userId, password);
      return password;
    }
    return false;
  },
  'users.remove'(userId){
    if(permission("removeUser") || userId == Meteor.userId()){
      check(userId, String);
      return Meteor.users.remove(userId);
    }
  }
});
