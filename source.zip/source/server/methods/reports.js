/*

Filename: /server/methods/reports.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements all methods and publishes for the collection reports

Copyright (c) 2019 - Robert Bosch LLC

*/

// All links-related publications
import { Meteor } from 'meteor/meteor';
import { check } from 'meteor/check';

import { Reports } from '../../imports/collections/reports.js';
import { Searches } from '../../imports/collections/searches.js';
import { Projects } from '../../imports/collections/projects.js';
import { Products } from '../../imports/collections/products.js';
import { Images } from '../../imports/collections/images.js';
import { mainElement, materialClass, getMaterialClasses } from '../../imports/elements.js';
import { permission } from '../../imports/permissions.js';

Meteor.publish('reports', ()=>{
  if(Meteor.userId()){
    return Reports.find({},{
      fields:{
        searchId: 1
      }
    });
  }
});


Meteor.publish('reports.get', (reportIds)=>{
  if(Meteor.userId()){
    return Reports.find({ _id: {$in: reportIds}});
  }
});

Meteor.methods({
  'reports.add'(searchId, results, excluded_elements){
    if(permission("createReport")){
      check(results, Array);
      check(searchId, String);

      let search = Searches.findOne(searchId,{
        fields: {
          name: 1,
          project: 1,
          description: 1,
          mainElement: 1,
          materialClass: 1,
          conclusion: 1,
          description: 1,
          instrument: 1,
          measurementDate: 1,
          analyst: 1
        }
      });
      delete search._id;
      search.excluded_elements = excluded_elements;

      // convert projectId to name
      let project = Projects.findOne(search.project);
      if(project){
        search.project = project.name;
      }

      // convert userId to name and department
      let analyst = Meteor.users.findOne(search.analyst);
      if(analyst){
        search.analyst = {
          name: analyst.name,
          department: analyst.department
        }
      }

      for(r in results){
        results[r].component.id;
        delete results[r].composition;
        delete results[r].intensity;

        // convert projectId to ProjectName
        let product = Products.findOne(results[r].component.product);
        if(product){
          results[r].component.product = product.name;
        }
      }

      if(search){


        let imageId = false;
        let image = Images.findOne({searchId},{fields:{}});
        if(image){
          imageId = image._id
        }

        let report = Reports.findOne({searchId},{fields:{}});
        if(report){

          Reports.update(report._id,{ $set: {
            searchId,
            search,
            results,
            imageId,
            changed: {
              from: Meteor.userId(),
              at: new Date()
            }
          } });
          return report._id;

        }else{

          // return the created reportId
          return Reports.insert({
            searchId,
            search,
            results,
            imageId,
            created:{
              from: Meteor.userId(),
              at: new Date()
            }
          });
        }
      }else{
        return {error: "Product not found"}
      }
    }
  }
});
