/*

Filename: /server/methods/projects.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements all methods and publishes for the collection projects

Copyright (c) 2019 - Robert Bosch LLC

*/

// All links-related publications
import { Meteor } from 'meteor/meteor';
import { check } from 'meteor/check';

import { Projects } from '../../imports/collections/projects.js';
import { Components } from '../../imports/collections/components.js';
import { Searches } from '../../imports/collections/searches.js';
import { permission } from '../../imports/permissions.js';
import { ucFirst } from '../../imports/functions.js';


Meteor.publish('projects', ()=>{
  if(Meteor.userId()){
    return Projects.find();
  }
});

Meteor.methods({
  'projects.add'(name){
    if(permission("addProject")){
      check(name, String);

      // return the created ProjectId
      return Projects.insert({
        name,
        owner: Meteor.userId(),
        created:{
          from: Meteor.userId(),
          at: new Date()
        }
      });
    }
  },
  'projects.setName'(projectId,name){
    if(permission("editProject")){
      check(name, String);

      return Projects.update(projectId,{ $set: {
        name,
        changed: {
          from: Meteor.userId(),
          at: new Date()
        }
      } });
    }
  },
  'projects.setOwner'(projectId,ownerId){
    if(permission("editProject")){
      check(projectId, String);
      check(ownerId, String);

      let owner = Meteor.users.findOne(ownerId);

      if(owner){
        return Projects.update(projectId,{ $set: {
          owner: owner._id,
          changed: {
            from: Meteor.userId(),
            at: new Date()
          }
        } });
      }
    }
  },
  'projects.addParticipant'(projectId,participantId){
    if(permission("editProject")){
      check(projectId, String);
      check(participantId, String);

      let participant = Meteor.users.findOne(participantId);
      let project = Projects.findOne(projectId);

      if(participant && project){

        if(!project.participants){
          project.participants = [participantId]
        }else if(!project.participants.includes(participantId)){
          project.participants.push(participantId);
        }

        return Projects.update(projectId,{ $set: {
          participants: project.participants,
          changed: {
            from: Meteor.userId(),
            at: new Date()
          }
        } });
      }
    }
  },
  'projects.removeParticipant'(projectId,participantId){
    if(permission("editProject")){
      check(projectId, String);
      check(participantId, String);

      let project = Projects.findOne(projectId);

      if(project){

        if(!project.participants){
          project.participants = []
        }else{
          project.participants = project.participants.filter(id => id != participantId);
        }

        return Projects.update(projectId,{ $set: {
          participants: project.participants,
          changed: {
            from: Meteor.userId(),
            at: new Date()
          }
        } });
      }
    }
  },
  'projects.remove'(projectId){
    if(permission("removeProject")){
      check(projectId, String);

      if(Searches.find({project: projectId}).count() > 0){
        return {error:"Searches found!"};
      }else{
        return Projects.remove(projectId);
      }
    }
  }
});
