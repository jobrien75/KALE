/*

Filename: /server/methods/searches.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements all methods and publishes for the collection searches

Copyright (c) 2019 - Robert Bosch LLC

*/

// All links-related publications
import { Meteor } from 'meteor/meteor';
import { check } from 'meteor/check';

import { Projects } from '../../imports/collections/projects.js';
import { Searches } from '../../imports/collections/searches.js';
import { Images } from '../../imports/collections/images.js';
import { Reports } from '../../imports/collections/reports.js';
import { attrFromName } from '../../imports/functions.js';
import { mainElement, materialClass, getMaterialClasses } from '../../imports/elements.js';
import { permission } from '../../imports/permissions.js';
import { calculateMatches } from '../../imports/matchCalculation.js';

Meteor.publish('searches', ()=>{
  if(Meteor.userId()){
    return Searches.find({},{
      fields: {
        name: 1,
        project: 1,
        mainElement: 1,
        report: 1
      }
    });
  }
});

Meteor.publish('mySearches', ()=>{
  if(Meteor.userId()){
    return Searches.find({
      $or: [
        {'analyst': Meteor.userId()},
        {'created.from': Meteor.userId()},
        {'changed.from': Meteor.userId()}
      ]
    },{
      sort:{
        "changed.at": -1,
        "created.at": -1,
      },
      fields: {
        name: 1,
        project: 1,
        mainElement: 1,
        report: 1,
        instrument: 1,
        analyst: 1,
        created: 1,
        changed: 1
      }
    });
  }
});

Meteor.publish('searches.get', (searchId)=>{
  check(searchId, String);

  if(Meteor.userId()){
    return Searches.find({ _id: searchId });
  }
});

Meteor.methods({
  'searches.add'(name,project,description){
    if(permission("addSearch")){
      check(name, String);
      check(project, String);
      check(description, String);

      return Searches.insert({
        name,
        project,
        description,
        created:{
          from: Meteor.userId(),
          at: new Date()
        }
      });
    }
  },
  'searches.setName'(searchId,name){
    if(permission("editSearch")){
      check(searchId, String);
      check(name, String);

      return Searches.update(searchId,{ $set: {
        name,
        changed: {
          from: Meteor.userId(),
          at: new Date()
        }
      } });
    }
  },
  'searches.setInstrument'(searchId,instrument){
    if(permission("editSearch")){
      check(searchId, String);
      check(instrument, String);

      return Searches.update(searchId,{ $set: {
        instrument,
        changed: {
          from: Meteor.userId(),
          at: new Date()
        }
      } });
    }
  },
  'searches.setDescription'(searchId,description){
    if(permission("editSearch")){
      check(searchId, String);
      check(description, String);

      return Searches.update(searchId,{ $set: {
        description,
        changed: {
          from: Meteor.userId(),
          at: new Date()
        }
      } });
    }
  },
  'searches.setConclusion'(searchId,conclusion){
    if(permission("editSearch")){
      check(searchId, String);
      check(conclusion, String);

      return Searches.update(searchId,{ $set: {
        conclusion,
        changed: {
          from: Meteor.userId(),
          at: new Date()
        }
      } });
    }
  },
  'searches.setProject'(searchId,projectId){
    if(permission("editSearch")){
      check(searchId, String);
      check(projectId, String);

      let project = Projects.findOne(projectId);

      if(project){
        return Searches.update(searchId,{ $set: {
          project: project._id,
          changed: {
            from: Meteor.userId(),
            at: new Date()
          }
        } });
      }
    }
  },
  'searches.setAnalyst'(searchId,analystId){
    if(permission("editSearch")){
      check(searchId, String);
      check(analystId, String);

      let analyst = Meteor.users.findOne(analystId);

      if(analyst){
        return Searches.update(searchId,{ $set: {
          analyst: analyst._id,
          changed: {
            from: Meteor.userId(),
            at: new Date()
          }
        } });
      }
    }
  },
  'searches.setMeasurementDate'(searchId,measurementDate){
    if(permission("editSearch")){
      check(searchId, String);
      check(measurementDate, Date);


      return Searches.update(searchId,{ $set: {
        measurementDate,
        changed: {
          from: Meteor.userId(),
          at: new Date()
        }
      } });
    }
  },
  'searches.setMaterialClass'(searchId,materialClass){
    if(permission("editSearch")){
      check(searchId, String);
      check(materialClass, String);

      let materialClasses = getMaterialClasses();

      if(!materialClasses.includes(materialClass)){
        return "invalid materialClass";
      }

      return Searches.update(searchId,{ $set: {
        materialClass,
        changed: {
          from: Meteor.userId(),
          at: new Date()
        }
      } });
    }
  },
  'searches.addComposition'(searchId,spectrumTitle,elements){
    if(permission("editComponent")){
      check(searchId, String);
      check(spectrumTitle, String);
      check(elements, Object);

      let search = Searches.findOne(searchId);

      if(search){
        if(!search.composition){
          search.composition = {};
        }

        if(!search.composition[attrFromName(spectrumTitle)]){
          search.composition[attrFromName(spectrumTitle)] = {
            title: spectrumTitle,
            elements
          };
        }else{
          search.composition[attrFromName(spectrumTitle)].elements = elements;
        }

        let composition = {};
        Object.keys(search.composition).sort().forEach(function(key) {
          composition[key] = search.composition[key];
        });

        return Searches.update(searchId,{ $set: {
          composition,
          mainElement: mainElement(elements),
          materialClass: materialClass(elements),
          analyst: Meteor.userId(),
          measurementDate: new Date(),
          changed: {
            from: Meteor.userId(),
            at: new Date()
          }
        } });

      }
    }
  },
  'searches.removeSpectrum'(searchId,spectrumTitle){
    if(permission("editSearch")){
      check(searchId, String);
      check(spectrumTitle, String);

      let search = Searches.findOne(searchId);

      if(search && search.composition){

        let newComposition = {};
        for(spectrum in search.composition){
          if(spectrum != attrFromName(spectrumTitle)){
            newComposition[spectrum] = search.composition[spectrum];
          }
        }
        search.composition = newComposition;


        if(search.intensity){
          let newIntensity = {};
          for(spectrum in search.intensity){
            if(spectrum != attrFromName(spectrumTitle)){
              newIntensity[spectrum] = search.intensity[spectrum];
            }
          }
          search.intensity = newIntensity;
        }

        search.changed = {
          from: Meteor.userId(),
          at: new Date()
        }

        return Searches.update(searchId,search);
      }
    }
  },
  'searches.addIntensity'(searchId,spectrumTitle,intensity){
    if(permission("editSearch")){
      check(searchId, String);
      check(spectrumTitle, String);
      check(intensity, Object);

      let search = Searches.findOne(searchId);

      if(search){

        if(!search.composition || !search.composition[attrFromName(spectrumTitle)]){
          return {error: spectrumTitle + " not found within "+search.name+", upload matching Composition-File first."};
        }else{
          if(!search.intensity){
            search.intensity = {};
          }

          search.instrument = intensity.signaltype;
          delete intensity.signaltype;
          search.measurementDate = intensity.date;
          delete intensity.date;

          search.analyst = Meteor.userId();
          search.intensity[attrFromName(spectrumTitle)] = intensity;

          let sortedIntensity = {};
          Object.keys(search.composition).forEach(function(key) {
            sortedIntensity[key] = search.intensity[key];
          });
          search.intensity = sortedIntensity;

        }

        search.changed = {
          from: Meteor.userId(),
          at: new Date()
        };

        return Searches.update(searchId,search);

      }
    }
  },
  'searches.compare'(searchId, algorithm, excluded_elements = [], nResults = 10,  minMatch = 0.5, product = "all", materialClass = "all"){
    check(searchId, String);

    return calculateMatches(searchId, algorithm, excluded_elements, nResults,  minMatch, product, materialClass);
  },
  'searches.remove'(searchId){
    check(searchId, String);
    if(permission("removeSearch")){
      Reports.find({searchId}).forEach((report)=>{
        Reports.remove(report._id);
      });
      Images.find({searchId}).forEach((image)=>{
        Images.remove(image._id);
      });

      return Searches.remove(searchId);
    }
  }
});
