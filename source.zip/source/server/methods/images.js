/*

Filename: /server/methods/images.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements all methods and publishes for the collection images

Copyright (c) 2019 - Robert Bosch LLC

*/

// All links-related publications
import { Meteor } from 'meteor/meteor';
import { check } from 'meteor/check';

import { Images } from '../../imports/collections/images.js';
import { Searches } from '../../imports/collections/searches.js';
import { permission } from '../../imports/permissions.js';


Meteor.publish('images.searchId', (searchId)=>{
  check(searchId, String);
  if(Meteor.userId()){
    return Images.find({searchId});
  }
});

Meteor.publish('images.get', (imageId)=>{
  check(imageId, String);
  return Images.find(imageId);
});

Meteor.methods({
  'images.addSearchImage'(searchId,jpegBase64){
    if(permission("editSearch")){
      check(searchId, String);
      check(jpegBase64, String);

      let search = Searches.findOne(searchId);

      if(search){

        let image = Images.findOne({searchId});

        if(image){
          return Images.update({searchId},{ $set: {
            jpegBase64,
            changed: {
              from: Meteor.userId(),
              at: new Date()
            }
          } });
        }else{
          return Images.insert({
            searchId,
            jpegBase64,
            created:{
              from: Meteor.userId(),
              at: new Date()
            }
          });
        }

      }
    }
  },
  'images.removeSearchImage'(searchId){
    if(permission("removeImage")){
      check(searchId, String);
      return Components.remove({searchId});
    }
  }
});
