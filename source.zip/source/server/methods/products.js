/*

Filename: /server/methods/products.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Implements all methods and publishes for the collection products

Copyright (c) 2019 - Robert Bosch LLC

*/

// All links-related publications
import { Meteor } from 'meteor/meteor';
import { check } from 'meteor/check';

import { Products } from '../../imports/collections/products.js';
import { Components } from '../../imports/collections/components.js';
import { permission } from '../../imports/permissions.js';
import { ucFirst } from '../../imports/functions.js';


Meteor.publish('products', ()=>{
  if(Meteor.userId()){
    return Products.find();
  }
});

Meteor.methods({
  'products.add'(name){
    if(permission("addProduct")){
      check(name, String);

      // return the created ProductId
      return Products.insert({
        name,
        created:{
          from: Meteor.userId(),
          at: new Date()
        }
      });
    }
  },
  'products.setName'(productId,name){
    if(permission("editProduct")){
      check(name, String);

      return Products.update(productId,{ $set: {
        name,
        changed: {
          from: Meteor.userId(),
          at: new Date()
        }
      } });
    }
  },
  'products.remove'(productId){
    if(permission("removeProduct")){
      check(productId, String);

      if(Components.find({product: productId}).count() > 0){
        return {error:"Components found!"};
      }else{
        return Products.remove(productId);
      }
    }
  }
});
