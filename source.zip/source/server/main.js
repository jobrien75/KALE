/*

Filename: /server/main.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Server entry point, imports all server code

Copyright (c) 2019 - Robert Bosch LLC

*/

import './startup.js';

import './methods/users.js';
import './methods/projects.js';
import './methods/searches.js';
import './methods/products.js';
import './methods/components.js';
import './methods/images.js';
import './methods/reports.js';

Accounts.config({
  forbidClientAccountCreation: true
});
