/*

Filename: /tests/main.js
Author: Matthias Hehn
Date: 26. August 2019
Description: Tests entry point, imports all test code

Copyright (c) 2019 - Robert Bosch LLC

*/

import assert from "assert";

describe("KALE", function () {
  it("package.json has correct name", async function () {
    const { name } = await import("../package.json");
    assert.strictEqual(name, "KALE");
  });

  if (Meteor.isClient) {
    it("client is not server", function () {
      assert.strictEqual(Meteor.isServer, false);
    });
  }

  if (Meteor.isServer) {
    it("server is not client", function () {
      assert.strictEqual(Meteor.isClient, false);
    });
  }
});
